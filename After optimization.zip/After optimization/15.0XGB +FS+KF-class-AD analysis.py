# -*- coding: utf-8 -*-
"""
Created on Thu Nov 14 01:32:31 2024

@author: dell
"""
import xgboost as xgb
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.svm import SVR
from sklearn.feature_selection import RFE
import numpy as np
import warnings
warnings.filterwarnings("ignore")
# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintXGB.csv'
# 从CSV文件中读取数据到DataFrame中
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
# 特征变量：选择所有行，从第4列开始到最后一列
X = che.iloc[:, 4:]
# 目标变量：从DataFrame中选择名为'k'的列，重塑为2D数组以适应scaler
y = che['k'].values.reshape(-1, 1)

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]
# 将类别特征转换成数字编码（0 到 26）
category_feature_encoded = category_feature.replace({
    'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
    'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
    'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
    'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26})

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X, category_feature_encoded], axis=1)

# 初始化 MinMaxScaler
scaler = MinMaxScaler()

# 对 X 进行归一化处理
X_normalized = scaler.fit_transform(X)

# 将归一化后的 X 转换为 DataFrame
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)

X = X_normalized_df
# 标准化数据
scaler = StandardScaler()
# 对目标变量进行对数变换
y = np.log1p(y)
# 对目标变量进行归一化
y = scaler.fit_transform(y)

# 特征选择
# 创建支持向量机回归模型
svm = SVR(kernel='linear')
# 使用递归特征消除（RFE）进行特征选择
n_features_to_select = 500
rfe = RFE(estimator=svm, n_features_to_select=n_features_to_select, step=1)
# 在全量数据上进行特征选择
rfe.fit(X, y.ravel())  # ravel()将y变成1维数组，符合RFE的输入要求
# 提取选择后的特征
selected_features = X.columns[rfe.support_]
# 根据选择的特征重新准备数据
X_selected = X[selected_features]

# 将数据分割为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

# 标准化数据（如果需要）
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 使用K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# 初始化空列表，用于存储每次交叉验证的性能指标
cv_scores = []

# 在每个交叉验证折上进行训练和评估
for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    # 创建并训练XGBoost回归器
    xgb_regressor_cv = xgb.XGBRegressor(
        n_estimators=1000,
        max_depth=21,
        min_child_weight=1,
        gamma=0.1,
        learning_rate=0.05,
        random_state=42
    )
    xgb_regressor_cv.fit(X_train_cv, y_train_cv)

    # 在验证集上进行预测
    y_pred_cv = xgb_regressor_cv.predict(X_val)

    # 计算均方误差（MSE）
    mse_cv = mean_squared_error(y_val, y_pred_cv)

    # 将MSE存储到列表中
    cv_scores.append(mse_cv)

# 计算交叉验证的均值和标准差
mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型（使用全部训练数据）
# 标准化所有训练数据
X_selected_scaled = scaler.fit_transform(X_selected)
# 创建并训练最终的XGBoost回归器
xgb_regressor = xgb.XGBRegressor(
    n_estimators=1000,
    max_depth=21,
    min_child_weight=1,
    gamma=0.1,
    learning_rate=0.05,
    random_state=42
)
xgb_regressor.fit(X_selected_scaled, y)

# 在训练集上进行预测
y_pred_train = xgb_regressor.predict(X_selected_scaled)

# 在测试集上进行预测（记得也要用选择后的特征）
X_test_selected = X_test[selected_features]
X_test_selected_scaled = scaler.transform(X_test_selected)
y_pred_test = xgb_regressor.predict(X_test_selected_scaled)

# 计算和打印均方误差（MSE）for训练集和测试集
mse_train = mean_squared_error(y, y_pred_train)
mse_test = mean_squared_error(y_test, y_pred_test)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for测试集
rmse_train = np.sqrt(mse_train)
rmse_test = np.sqrt(mse_test)
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

# 计算R平方（R2）for训练集
r2_train = r2_score(y, y_pred_train)
print(f"训练集R平方（R2）: {r2_train:.4f}")
# 计算R平方（R2）for测试集
r2_test = r2_score(y_test, y_pred_test)
print(f"测试集R平方（R2）: {r2_test:.4f}")

# --- AD分析部分 ---
# 计算Tanimoto相似度（计算每个测试化合物与训练集中所有化合物的相似度）
def tanimoto_index(mf_a, mf_b):
    Nc = np.sum((mf_a == 1) & (mf_b == 1))  # 1s in both MF vectors
    Na = np.sum(mf_a == 1)  # 1s in MF A
    Nb = np.sum(mf_b == 1)  # 1s in MF B
    return Nc / (Na + Nb - Nc)

# 计算测试集化合物与训练集化合物的Tanimoto相似度
similarity_matrix = np.zeros((X_test_selected_scaled.shape[0], X_selected_scaled.shape[0]))
for i, test_sample in enumerate(X_test_selected_scaled):
    for j, train_sample in enumerate(X_selected_scaled):
        similarity_matrix[i, j] = tanimoto_index(test_sample, train_sample)

# 设置新的相似度阈值组合（增加更高的最大相似度阈值和更低的平均相似度阈值）
threshold_max_values = [0.25]  # 更高的最大相似度阈值
threshold_mean_values = [0.08]  # 更低的平均相似度阈值

results = []

# 计算最大相似度和平均相似度
max_similarity = similarity_matrix.max(axis=1)
mean_similarity = similarity_matrix.mean(axis=1)

# 计算每个阈值下的AD外化合物数量和R²
for threshold_max in threshold_max_values:
    for threshold_mean in threshold_mean_values:
        # 获取不在AD中的化合物
        outside_ad_max = np.where(max_similarity < threshold_max)[0]
        outside_ad_mean = np.where(mean_similarity < threshold_mean)[0]

        # 计算AD内化合物的R²
        inside_ad_max = np.setdiff1d(np.arange(len(y_test)), outside_ad_max)
        inside_ad_mean = np.setdiff1d(np.arange(len(y_test)), outside_ad_mean)

        # 计算AD内的R²
        r2_within_ad_max = r2_score(y_test[inside_ad_max], y_pred_test[inside_ad_max]) if len(inside_ad_max) > 0 else np.nan
        r2_within_ad_mean = r2_score(y_test[inside_ad_mean], y_pred_test[inside_ad_mean]) if len(inside_ad_mean) > 0 else np.nan

        # 计算AD外的R²
        r2_outside_ad_max = r2_score(y_test[outside_ad_max], y_pred_test[outside_ad_max]) if len(outside_ad_max) > 0 else np.nan
        r2_outside_ad_mean = r2_score(y_test[outside_ad_mean], y_pred_test[outside_ad_mean]) if len(outside_ad_mean) > 0 else np.nan

        # 打印每一组阈值的详细信息
        print(f"最大相似度阈值: {threshold_max}, 平均相似度阈值: {threshold_mean}")
        print(f"超出最大相似度阈值（{threshold_max}）的化合物数量: {len(outside_ad_max)}")
        print(f"超出平均相似度阈值（{threshold_mean}）的化合物数量: {len(outside_ad_mean)}")
        print(f"最大相似度阈值下，AD内化合物的R²: {r2_within_ad_max}")
        print(f"平均相似度阈值下，AD内化合物的R²: {r2_within_ad_mean}")
        print(f"最大相似度阈值下，AD外化合物的R²: {r2_outside_ad_max}")
        print(f"平均相似度阈值下，AD外化合物的R²: {r2_outside_ad_mean}")
        print("-" * 50)

        results.append({
            'Threshold max': threshold_max,
            'Threshold mean': threshold_mean,
            'AD outside count max': len(outside_ad_max),
            'AD outside count mean': len(outside_ad_mean),
            'R2 test max': r2_within_ad_max,
            'R2 test mean': r2_within_ad_mean,
            'R2 outside max': r2_outside_ad_max,
            'R2 outside mean': r2_outside_ad_mean
        })

# 输出结果表格
result_df = pd.DataFrame(results)
print(result_df)

print(result_df)
