# -*- coding: utf-8 -*-
"""
Created on Mon Jul 22 16:01:47 2024

@author: dell
"""
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import warnings

warnings.filterwarnings("ignore")

# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintMLP.csv'
# 从CSV文件中读取数据到DataFrame中
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
# 特征变量：选择所有行，从第4列开始到最后一列
X = che.iloc[:, 4:]
# 目标变量：从DataFrame中选择名为'k'的列，重塑为2D数组以适应scaler
y = che['k'].values.reshape(-1, 1)

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]
# 将类别特征转换成数字编码（0 到 26）
category_feature_encoded = category_feature.replace({
    'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
    'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
    'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
    'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26})

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X, category_feature_encoded.rename('category')], axis=1)

# 检查数据框架的形状，确保列数一致
print("X shape:", X.shape)
print("y shape:", y.shape)

# 初始化 MinMaxScaler，对 X 进行归一化处理
scaler = MinMaxScaler()
X_normalized = scaler.fit_transform(X)
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)
X = X_normalized_df

# 对目标变量进行对数变换
y = np.log1p(y)

# 初始化 MinMaxScaler，对目标变量进行归一化
scaler_y = MinMaxScaler()
y_normalized = scaler_y.fit_transform(y)

# 定义最佳超参数值
best_num_layers = 9   
best_num_neurons = 657
best_learning_rate = 0.0096

# 创建多层感知机模型
model = Sequential()
model.add(Dense(best_num_neurons, activation='relu', input_shape=(X.shape[1],)))
for _ in range(best_num_layers):
    model.add(Dense(best_num_neurons, activation='relu'))
model.add(Dense(1))  # 输出层

# 编译模型，选择优化器和损失函数
model.compile(optimizer='adam', loss='mean_squared_error')

# 将数据分割为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y_normalized, test_size=0.2, random_state=42)

# 训练模型
history = model.fit(X_train, y_train, validation_split=0.2, epochs=1000, batch_size=60, verbose=1)

# 评估模型在测试集上的性能
test_loss = model.evaluate(X_test, y_test)
print('Test Loss:', test_loss)

# 在训练集上进行预测
y_pred_train = model.predict(X_train)

# 在测试集上进行预测
y_pred_test = model.predict(X_test)

# 逆向变换预测结果和目标变量
y_train_inverse = np.expm1(scaler_y.inverse_transform(y_train))
y_pred_train_inverse = np.expm1(scaler_y.inverse_transform(y_pred_train))
y_test_inverse = np.expm1(scaler_y.inverse_transform(y_test))
y_pred_test_inverse = np.expm1(scaler_y.inverse_transform(y_pred_test))

# 计算对数值（以10为底）
y_train_log10 = np.log10(y_train_inverse + 1)
y_pred_train_log10 = np.log10(y_pred_train_inverse + 1)
y_test_log10 = np.log10(y_test_inverse + 1)
y_pred_test_log10 = np.log10(y_pred_test_inverse + 1)

# 创建训练集预测结果的 DataFrame
train_results_df = pd.DataFrame({
    'y_train_log10': y_train_log10.flatten(),
    'y_pred_train_log10': y_pred_train_log10.flatten()
})
train_output_path = 'H:/Pythoncodes/1/add class/1.0MLPtrain_prediction_results_log10.csv'
train_results_df.to_csv(train_output_path, index=False)

# 创建测试集预测结果的 DataFrame
test_results_df = pd.DataFrame({
    'y_test_log10': y_test_log10.flatten(),
    'y_pred_test_log10': y_pred_test_log10.flatten()
})
test_output_path = 'H:/Pythoncodes/1/add class/1.0MLPtest_prediction_results_log10.csv'
test_results_df.to_csv(test_output_path, index=False)

# 读取训练集和测试集预测结果
train_df = pd.read_csv(train_output_path)
test_df = pd.read_csv(test_output_path)

# 确保训练集和测试集数据框的列名不重复
train_df.columns = [f'train_{col}' for col in train_df.columns]
test_df.columns = [f'test_{col}' for col in test_df.columns]

# 将测试集结果合并到训练集的后面
combined_df = pd.concat([train_df, test_df], axis=1)

# 保存合并后的结果
combined_output_path = 'H:/Pythoncodes/1/add class/1.0MLPcombined_prediction_results_log10.csv'
combined_df.to_csv(combined_output_path, index=False)

print(f"合并后的文件已保存到: {combined_output_path}")







