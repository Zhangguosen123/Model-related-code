# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 15:24:13 2024

@author: dell
"""
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.linear_model import BayesianRidge
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.feature_selection import RFE
import numpy as np
import warnings

warnings.filterwarnings("ignore")

# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintBayR.csv'
# 从CSV文件中读取数据到DataFrame中
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:, 4:]  # 特征变量：选择所有行，从第4列开始到最后一列
y = che['k'].values.reshape(-1, 1)  # 目标变量：从DataFrame中选择名为'k'的列，重塑为2D数组以适应scaler

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]
category_feature_encoded = category_feature.replace({
    'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
    'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
    'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
    'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26
})

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X, category_feature_encoded], axis=1)

# 初始化 MinMaxScaler 对 X 进行归一化处理
scaler = MinMaxScaler()
X_normalized = scaler.fit_transform(X)

# 将归一化后的 X 转换为 DataFrame
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)
X = X_normalized_df

# 标准化数据和目标变量对数变换
scaler = StandardScaler()
y = np.log1p(y)
y = scaler.fit_transform(y)

# 特征选择
bayesian_ridge = BayesianRidge()
n_features_to_select = 500
rfe = RFE(estimator=bayesian_ridge, n_features_to_select=n_features_to_select, step=1)
rfe.fit(X, y.ravel())
selected_features = X.columns[rfe.support_]
X_selected = X[selected_features]

# 分割数据集
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

# 标准化数据
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    bayesian_ridge_regressor_cv = BayesianRidge(
        alpha_1=23.73,
        alpha_2=57.54,
        lambda_1=14.19,
        lambda_2=21.18,
    )
    bayesian_ridge_regressor_cv.fit(X_train_cv, y_train_cv)
    y_pred_cv = bayesian_ridge_regressor_cv.predict(X_val)

    mse_cv = mean_squared_error(y_val, y_pred_cv)
    cv_scores.append(mse_cv)

mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型
X_selected_scaled = scaler.fit_transform(X_selected)
bayesian_ridge_regressor = BayesianRidge(
    alpha_1=23.73,
    alpha_2=57.54,
    lambda_1=14.19,
    lambda_2=21.18,
)
bayesian_ridge_regressor.fit(X_selected_scaled, y)

# 对每个类别分别进行预测和评估
category_results = {}

for category in category_feature_encoded.unique():
    category_idx = category_feature_encoded == category
    X_category = X_selected[category_idx]
    y_category = y[category_idx]
    
    X_category_scaled = scaler.transform(X_category)
    
    y_pred_category = bayesian_ridge_regressor.predict(X_category_scaled)
    
    mse_category = mean_squared_error(y_category, y_pred_category)
    rmse_category = np.sqrt(mse_category)
    mae_category = mean_absolute_error(y_category, y_pred_category)
    r2_category = r2_score(y_category, y_pred_category)
    
    # 计算 MAE 百分比（假设基准值为 y_category 的均值）
    mae_percentage = (mae_category / np.mean(y_category)) * 100
    
    category_results[category] = {
        'MSE': mse_category,
        'RMSE': rmse_category,
        'MAE (%)': mae_percentage,
        'R²': r2_category
    }

# 输出每个类别的预测性能
for category, metrics in category_results.items():
    print(f"Category: {category}")
    print(f"  MSE: {metrics['MSE']:.4f}")
    print(f"  RMSE: {metrics['RMSE']:.4f}")
    print(f"  MAE (%): {metrics['MAE (%)']:.2f}%")
    print(f"  R²: {metrics['R²']:.4f}")

