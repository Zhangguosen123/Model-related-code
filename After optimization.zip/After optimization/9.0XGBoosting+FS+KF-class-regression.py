# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 13:21:07 2024

@author: dell
"""
import xgboost as xgb
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.svm import SVR
from sklearn.feature_selection import RFE
import numpy as np
import warnings

warnings.filterwarnings("ignore")

# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintXGB.csv'

# 从CSV文件中读取数据到DataFrame中
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:, 4:]
y = che['k'].values.reshape(-1, 1)

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]
category_feature_encoded = category_feature.replace({
    'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
    'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
    'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
    'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26})

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X, category_feature_encoded], axis=1)

# 初始化 MinMaxScaler
scaler = MinMaxScaler()
X_normalized = scaler.fit_transform(X)
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)
X = X_normalized_df

# 标准化数据
scaler_y = StandardScaler()
y_log = np.log1p(y)
y_scaled = scaler_y.fit_transform(y_log)

# 特征选择
svm = SVR(kernel='linear')
n_features_to_select = 500
rfe = RFE(estimator=svm, n_features_to_select=n_features_to_select, step=1)
rfe.fit(X, y_scaled.ravel())
selected_features = X.columns[rfe.support_]
X_selected = X[selected_features]

# 将数据分割为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_selected, y_scaled, test_size=0.2, random_state=42)

# 标准化数据（如果需要）
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

# 使用K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    xgb_regressor_cv = xgb.XGBRegressor(
        n_estimators=1000,
        max_depth=21,
        min_child_weight=1,
        gamma=0.1,
        learning_rate=0.05,
        random_state=42
    )
    xgb_regressor_cv.fit(X_train_cv, y_train_cv)
    y_pred_cv = xgb_regressor_cv.predict(X_val)
    mse_cv = mean_squared_error(y_val, y_pred_cv)
    cv_scores.append(mse_cv)

mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型（使用全部训练数据）
X_selected_scaled = scaler_X.fit_transform(X_selected)
xgb_regressor = xgb.XGBRegressor(
    n_estimators=1000,
    max_depth=21,
    min_child_weight=1,
    gamma=0.1,
    learning_rate=0.05,
    random_state=42
)
xgb_regressor.fit(X_selected_scaled, y_scaled)

# 在训练集上进行预测
y_pred_train = xgb_regressor.predict(X_selected_scaled)

# 在测试集上进行预测（记得也要用选择后的特征）
X_test_selected = X_test[selected_features]
X_test_selected_scaled = scaler_X.transform(X_test_selected)
y_pred_test = xgb_regressor.predict(X_test_selected_scaled)

# 逆向变换归一化并计算对数值（以10为底）
y_log = np.expm1(scaler_y.inverse_transform(y_scaled))
y_pred_train_log = np.expm1(scaler_y.inverse_transform(y_pred_train.reshape(-1, 1)))
y_test_log = np.expm1(scaler_y.inverse_transform(y_test.reshape(-1, 1)))
y_pred_test_log = np.expm1(scaler_y.inverse_transform(y_pred_test.reshape(-1, 1)))

# 计算对数值（以10为底）
y_log_10 = np.log10(y_log + 1)
y_pred_train_log_10 = np.log10(y_pred_train_log + 1)
y_test_log_10 = np.log10(y_test_log + 1)
y_pred_test_log_10 = np.log10(y_pred_test_log + 1)

# 创建训练集预测结果的 DataFrame
train_results_df = pd.DataFrame({
    'y_log_10': y_log_10.flatten(),
    'y_pred_train_log_10': y_pred_train_log_10.flatten()
})
train_output_path = 'H:/Pythoncodes/1/add class/9.0XGBtrain_prediction_results_log10.csv'
train_results_df.to_csv(train_output_path, index=False)

# 创建测试集预测结果的 DataFrame
test_results_df = pd.DataFrame({
    'y_test_log_10': y_test_log_10.flatten(),
    'y_pred_test_log_10': y_pred_test_log_10.flatten()
})
test_output_path = 'H:/Pythoncodes/1/add class/9.0XGBtest_prediction_results_log10.csv'
test_results_df.to_csv(test_output_path, index=False)

# 读取训练集和测试集预测结果
train_df = pd.read_csv(train_output_path)
test_df = pd.read_csv(test_output_path)

# 将测试集结果合并到训练集的后面
combined_df = pd.concat([train_df, test_df], axis=1)

# 保存合并后的结果
combined_output_path = 'H:/Pythoncodes/1/add class/9.0XGBcombined_prediction_results_log10.csv'
combined_df.to_csv(combined_output_path, index=False)

print(f"合并后的文件已保存到: {combined_output_path}")

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for训练集和测试集
mse_train = mean_squared_error(np.expm1(scaler_y.inverse_transform(y_scaled)), y_pred_train)
mse_test = mean_squared_error(np.expm1(scaler_y.inverse_transform(y_test)), y_pred_test)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")

rmse_train = np.sqrt(mse_train)
rmse_test = np.sqrt(mse_test)
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

# 计算R平方（R2）for训练集
r2_train = r2_score(np.expm1(scaler_y.inverse_transform(y_scaled)), y_pred_train)
print(f"训练集R平方（R2）: {r2_train:.4f}")

# 计算R平方（R2）for测试集
r2_test = r2_score(np.expm1(scaler_y.inverse_transform(y_test)), y_pred_test)
print(f"测试集R平方（R2）: {r2_test:.4f}")

