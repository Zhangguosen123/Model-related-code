# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 15:06:49 2024

@author: dell
"""
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import ARDRegression
from sklearn.metrics import r2_score, mean_squared_error
from rdkit import Chem
from rdkit.Chem import AllChem
from bayes_opt import BayesianOptimization
import warnings

warnings.filterwarnings("ignore")

def ard(fp_size, radius, tol, threshold_lambda):
    # 定义一个函数，用于将 SMILES 字符串转换为分子指纹
    def smiles_to_fingerprint(smiles, fp_size=int(fp_size)):
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is not None:
            fingerprint = AllChem.GetMorganFingerprintAsBitVect(molecule, radius=int(radius), nBits=fp_size)
            return np.array(fingerprint, dtype=int)
        else:
            return [np.nan] * fp_size

    # 读取CSV文件并创建DataFrame对象
    filename = 'H:/Pythoncodes/1/add class/OH-SMILESClass0.csv'
    che = pd.read_csv(filename, header=0)

    # 应用函数并创建一个新的DataFrame来存储分子指纹
    fingerprints = [smiles_to_fingerprint(smiles) for smiles in che['Smiles']]
    fingerprint_df = pd.DataFrame(fingerprints)

    # 将指纹与原始数据合并
    che_fingerprint = pd.concat([che, fingerprint_df], axis=1)

    che = che_fingerprint

    # 分离特征和目标变量
    X = che.iloc[:, 4:]
    y = che['k'].values.reshape(-1, 1)

    # 处理类别特征列
    category_feature = che.iloc[:, 2]
    category_feature_encoded = category_feature.replace({
        'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
        'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
        'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
        'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26}).to_frame()

    # 初始化 MinMaxScaler
    scaler = MinMaxScaler()

    # 对类别特征进行归一化
    category_feature_normalized = scaler.fit_transform(category_feature_encoded.values.reshape(-1, 1))

    # 对数值特征进行归一化
    X_normalized = scaler.fit_transform(X)

    # 合并特征
    X = pd.concat([pd.DataFrame(X_normalized), pd.DataFrame(category_feature_normalized)], axis=1)
    X.columns = X.columns.astype(str)  # 确保列名的一致性

    # 标准化数据
    scaler = StandardScaler()
    y = np.log1p(y)
    y = scaler.fit_transform(y)

    X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=42)

    # 使用 ARDRegression
    ard_regressor = ARDRegression(
        tol=tol,                # 收敛容差
        threshold_lambda=threshold_lambda # 正则化参数
    )
    # 训练模型
    ard_regressor.fit(X_train, y_train_scaled)

    # 预测测试集
    y_pred = ard_regressor.predict(X_test)

    # 计算和打印均方误差（MSE）和均方根误差（RMSE）for测试集
    mse_test = mean_squared_error(y_test_scaled, y_pred)
    rmse_test = np.sqrt(mse_test)
    # 计算R平方（R2）for测试集
    r2_test = r2_score(y_test_scaled, y_pred)
    print(f"测试集R平方（R2）: {r2_test:.4f}")

    return r2_test

# 定义超参数搜索空间
search_space = {
    'fp_size': (16, 12288),
    'radius': (1, 16),
    'tol': (0.0001, 0.1),
    'threshold_lambda': (1, 10000)
}

# Bayesian优化器的初始化
opt = BayesianOptimization(
    ard,
    search_space,
    random_state=42
)

# 进行优化，设置迭代次数
opt.maximize(n_iter=100)

# 获取最佳参数与最佳分数
params_best = opt.max["params"]
score_best = opt.max["target"]

# 打印最佳参数与最佳分数
print("\n", "\n", "best params: ", params_best,
      "\n", "\n", "best cvscore: ", score_best)

