# -*- coding: utf-8 -*-
"""
Created on Wed Aug 28 10:43:13 2024

@author: dell
"""
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.linear_model import BayesianRidge
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.feature_selection import RFE
import numpy as np
import shap
import matplotlib.pyplot as plt
from scipy.stats import pointbiserialr
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import seaborn as sns
import warnings

warnings.filterwarnings("ignore")

# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintBayR.csv'
# 从CSV文件中读取数据到DataFrame中
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:, 4:]
y = che['k'].values.reshape(-1, 1)

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]
category_feature_encoded = category_feature.replace({
    'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
    'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
    'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
    'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26})

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X, category_feature_encoded], axis=1)

# 初始化 MinMaxScaler
scaler = MinMaxScaler()

# 对 X 进行归一化处理
X_normalized = scaler.fit_transform(X)

# 将归一化后的 X 转换为 DataFrame
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)

X = X_normalized_df

# 标准化数据
scaler = StandardScaler()
# 对目标变量进行对数变换
y = np.log1p(y)
# 对目标变量进行标准化
y = scaler.fit_transform(y)

# 特征选择
bayesian_ridge = BayesianRidge()
n_features_to_select = 500  # 根据实际情况调整
rfe = RFE(estimator=bayesian_ridge, n_features_to_select=n_features_to_select, step=1)
rfe.fit(X, y.ravel())
selected_features = X.columns[rfe.support_]
X_selected = X[selected_features]

# 将数据分割为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

# 标准化数据
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 使用K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    bayesian_ridge_regressor_cv = BayesianRidge(
        alpha_1=23.73,
        alpha_2=57.54,
        lambda_1=14.19,
        lambda_2=21.18,
    )
    bayesian_ridge_regressor_cv.fit(X_train_cv, y_train_cv)
    y_pred_cv = bayesian_ridge_regressor_cv.predict(X_val)
    mse_cv = mean_squared_error(y_val, y_pred_cv)
    cv_scores.append(mse_cv)

mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

X_selected_scaled = scaler.fit_transform(X_selected)
bayesian_ridge_regressor = BayesianRidge(
        alpha_1=23.73,
        alpha_2=57.54,
        lambda_1=14.19,
        lambda_2=21.18,
)
bayesian_ridge_regressor.fit(X_selected_scaled, y)
y_pred_train = bayesian_ridge_regressor.predict(X_selected_scaled)
X_test_selected = X_test[selected_features]
X_test_selected_scaled = scaler.transform(X_test_selected)
y_pred_test = bayesian_ridge_regressor.predict(X_test_selected_scaled)

mse_train = mean_squared_error(y, y_pred_train)
mse_test = mean_squared_error(y_test, y_pred_test)
rmse_train = np.sqrt(mse_train)
rmse_test = np.sqrt(mse_test)
r2_train = r2_score(y, y_pred_train)
r2_test = r2_score(y_test, y_pred_test)

print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")
print(f"训练集R平方（R2）: {r2_train:.4f}")
print(f"测试集R平方（R2）: {r2_test:.4f}")

# 计算SHAP值
explainer = shap.LinearExplainer(bayesian_ridge_regressor, X_selected_scaled)
shap_values = explainer.shap_values(X_selected_scaled)

# 计算每个特征的平均绝对SHAP值
mean_abs_shap_values = np.mean(np.abs(shap_values), axis=0)

# 获取前20个mean |SHAP value|值最大的特征及其对应的mean |SHAP value|值
top_20_indices = np.argsort(mean_abs_shap_values)[-20:][::-1]
top_20_features = X_selected.columns[top_20_indices]
top_20_shap_values = mean_abs_shap_values[top_20_indices]

# 获取前10个mean |SHAP value|值最大的特征及其对应的mean |SHAP value|值
top_10_indices = top_20_indices[:10]
top_10_features = X_selected.columns[top_10_indices]
top_10_shap_values = mean_abs_shap_values[top_10_indices]

print("前20个特征及其对应的mean |SHAP value|值:")
for feature, shap_value in zip(top_20_features, top_20_shap_values):
    print(f"{feature}: {shap_value:.4f}")

import matplotlib.pyplot as plt
import shap

# 设置保存路径
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\ML：氧化剂与污染物降解\模型结果图-tif和eps1'

# 绘制前10个特征的平均绝对SHAP值的条形图
plt.figure(figsize=(10, 5))
plt.barh(top_10_features, top_10_shap_values)
plt.xlabel('mean (|SHAP value|)(average impact on model output magnitude)')
plt.gca().invert_yaxis()

# 保存为 PDF 格式，确保标签不被截断
plt.savefig(f'{save_path}\\top_10_features_shap_values.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

# 绘制前20个特征的平均绝对SHAP值的条形图
plt.figure(figsize=(10, 10))
plt.barh(top_20_features, top_20_shap_values)
plt.xlabel('mean (|SHAP value|)(average impact on model output magnitude)')
plt.gca().invert_yaxis()

# 保存为 PDF 格式，确保标签不被截断
plt.savefig(f'{save_path}\\top_20_features_shap_values.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

import matplotlib.pyplot as plt
import shap
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.inspection import PartialDependenceDisplay
import matplotlib as mpl

# 设置保存路径
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\ML：氧化剂与污染物降解\模型结果图-tif和eps1'

# 设置matplotlib输出的PDF为Illustrator可编辑的字体
mpl.rcParams['pdf.fonttype'] = 42

# 1. 绘制前10个特征的SHAP重要性排序图并保存为PDF
plt.figure()
shap.summary_plot(shap_values[:, top_10_indices], X_selected.iloc[:, top_10_indices], plot_type="dot", color_bar=True)
fig = plt.gcf()
fig.set_size_inches(8, 7)
plt.tight_layout()
plt.savefig(f'{save_path}\\shap_summary_top_10.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

# 2. 绘制前20个特征的SHAP重要性排序图并保存为PDF
plt.figure()
shap.summary_plot(shap_values[:, top_20_indices], X_selected.iloc[:, top_20_indices], plot_type="dot", color_bar=True)
fig = plt.gcf()
fig.set_size_inches(8, 7)
plt.tight_layout()
plt.savefig(f'{save_path}\\shap_summary_top_20.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

# 3. 绘制前10个特征的SHAP相关热图并保存为PDF
plt.figure(figsize=(10, 5))
shap.summary_plot(shap_values[:, top_10_indices], X_selected.iloc[:, top_10_indices], plot_type="heatmap", color_bar=True)
fig = plt.gcf()
fig.set_size_inches(8, 7)
plt.tight_layout()
plt.savefig(f'{save_path}\\shap_heatmap_top_10.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

# 4. 绘制相关性热图并保存为PDF
top_10_features_data = X_selected.iloc[:, top_10_indices]
correlation_matrix = top_10_features_data.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0, linewidths=0.5, fmt=".2f")
# plt.title('Correlation Matrix for Top 10 Features')
plt.savefig(f'{save_path}\\correlation_matrix_top_10_features.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

# 5. 绘制每个特征的c-ICE图并保存为PDF
top_5_indices = top_20_indices[:5]
top_5_features = X_selected.columns[top_5_indices]
explainer = shap.LinearExplainer(bayesian_ridge_regressor, X_selected_scaled)
shap_values = explainer.shap_values(X_selected_scaled)
for feature in top_5_features:
    plt.figure(figsize=(10, 5))
    shap.dependence_plot(feature, shap_values, X_selected, interaction_index=None)
    fig = plt.gcf()
    fig.set_size_inches(8, 7)
    plt.tight_layout()
    plt.savefig(f'{save_path}\\c_ICE_{feature}.pdf', format='pdf', dpi=300, bbox_inches='tight')
    plt.show()

# 6. 绘制和保存PDPs
feature_pairs = [
    ('Chemical classes (27)', '1133'),
    ('Chemical classes (27)', '3045'),
    ('Chemical classes (27)', '5000'),
    ('Chemical classes (27)', '1231')
]
feature_indices = [
    (X_selected.columns.get_loc(pair[0]), X_selected.columns.get_loc(pair[1])) 
    for pair in feature_pairs
]
for i, (feature_1_idx, feature_2_idx) in enumerate(feature_indices):
    fig, ax = plt.subplots(figsize=(10, 6))
    PartialDependenceDisplay.from_estimator(bayesian_ridge_regressor, X_selected, features=[(feature_1_idx, feature_2_idx)], ax=ax, grid_resolution=50, kind='average')
    ax.set_xlabel(f'{feature_pairs[i][0]}')
    ax.set_ylabel(f'{feature_pairs[i][1]}')
    plt.savefig(f'{save_path}\\pdp_{feature_pairs[i][0]}_{feature_pairs[i][1]}.pdf', format='pdf', dpi=300, bbox_inches='tight')
    plt.show()

# 7. 绘制t-SNE图并保存为PDF
features = ['1133', '3045', '5000', '1231']
for feature in features:
    X_for_tsne = X_selected[[feature, 'Chemical classes (27)']]
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_for_tsne)
    tsne = TSNE(n_components=2, random_state=42)
    X_tsne = tsne.fit_transform(X_pca)
    plt.figure(figsize=(10, 6))
    scatter = plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=X_selected['Chemical classes (27)'], cmap='viridis', alpha=0.7)
    plt.colorbar(scatter, label='Chemical classes (27)')
    plt.xlabel('t-SNE Component 1')
    plt.ylabel('t-SNE Component 2')
    plt.savefig(f'{save_path}\\tsne_{feature}_Chemical_classes_27.pdf', format='pdf', dpi=300, bbox_inches='tight')
    plt.show()
