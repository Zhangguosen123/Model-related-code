# -*- coding: utf-8 -*-
"""
Created on Tue Aug  6 20:32:28 2024

@author: dell
"""
import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import train_test_split, KFold
from sklearn.linear_model import BayesianRidge
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.feature_selection import RFE
import numpy as np
import shap
import warnings

warnings.filterwarnings("ignore")

# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-SMILESClass0.csv'
# 读取CSV文件并创建DataFrame对象
che = pd.read_csv(filename, header=0)

# 应用函数并创建一个新的DataFrame来存储分子指纹
def smiles_to_fingerprint(smiles, fp_size=7323):
    molecule = Chem.MolFromSmiles(smiles)
    if molecule is not None:
        fingerprint = AllChem.GetMorganFingerprintAsBitVect(molecule, radius=2, nBits=fp_size)
        return np.array(fingerprint, dtype=int)
    else:
        return [np.nan] * fp_size

fingerprints = [smiles_to_fingerprint(smiles) for smiles in che['Smiles']]
fingerprint_df = pd.DataFrame(fingerprints)

# 如果你想要在同一个DataFrame中保留原始的SMILES字符串和分子指纹，可以这样做：
che_fingerprint = pd.concat([che, fingerprint_df], axis=1)

# 保存修改后的DataFrame到CSV文件
che_fingerprint.to_csv('H:/Pythoncodes/1/add class/OH-FringerprintBayR.csv', index=False)

# 从CSV文件中读取数据到DataFrame中
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintBayR.csv'
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:, 4:]
y = che['k'].values.reshape(-1, 1)

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]
# 将类别特征转换成数字编码（0 到 26）
category_feature_encoded = category_feature.replace({
    'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
    'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
    'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
    'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26})

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X, category_feature_encoded], axis=1)

# 初始化 MinMaxScaler
scaler = MinMaxScaler()
X_normalized = scaler.fit_transform(X)
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)
X = X_normalized_df

# 标准化数据
scaler = StandardScaler()
y = np.log1p(y)
y = scaler.fit_transform(y)

# 特征选择
bayesian_ridge = BayesianRidge()
n_features_to_select = 500  # 根据实际情况调整
rfe = RFE(estimator=bayesian_ridge, n_features_to_select=n_features_to_select, step=1)
rfe.fit(X, y.ravel())
selected_features = X.columns[rfe.support_]
X_selected = X[selected_features]

# 将数据分割为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 使用K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    bayesian_ridge_regressor_cv = BayesianRidge(
        alpha_1=23.73,
        alpha_2=57.54,
        lambda_1=14.19,
        lambda_2=21.18,
    )
    bayesian_ridge_regressor_cv.fit(X_train_cv, y_train_cv)
    y_pred_cv = bayesian_ridge_regressor_cv.predict(X_val)
    mse_cv = mean_squared_error(y_val, y_pred_cv)
    cv_scores.append(mse_cv)

mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型（使用全部训练数据）
X_selected_scaled = scaler.fit_transform(X_selected)
bayesian_ridge_regressor = BayesianRidge(
    alpha_1=23.73,
    alpha_2=57.54,
    lambda_1=14.19,
    lambda_2=21.18,
)
bayesian_ridge_regressor.fit(X_selected_scaled, y)

y_pred_train = bayesian_ridge_regressor.predict(X_selected_scaled)
X_test_selected = X_test[selected_features]
X_test_selected_scaled = scaler.transform(X_test_selected)
y_pred_test = bayesian_ridge_regressor.predict(X_test_selected_scaled)

mse_train = mean_squared_error(y, y_pred_train)
mse_test = mean_squared_error(y_test, y_pred_test)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")

rmse_train = np.sqrt(mse_train)
rmse_test = np.sqrt(mse_test)
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

r2_train = r2_score(y, y_pred_train)
print(f"训练集R平方（R2）: {r2_train:.4f}")
r2_test = r2_score(y_test, y_pred_test)
print(f"测试集R平方（R2）: {r2_test:.4f}")

# 计算SHAP值
explainer = shap.LinearExplainer(bayesian_ridge_regressor, X_selected_scaled)
shap_values = explainer.shap_values(X_selected_scaled)
mean_abs_shap_values = np.mean(np.abs(shap_values), axis=0)

# 获取前20个mean |SHAP value|值最大的特征及其对应的mean |SHAP value|值
top_20_indices = np.argsort(mean_abs_shap_values)[-20:][::-1]
top_20_features = X_selected.columns[top_20_indices]
top_20_shap_values = mean_abs_shap_values[top_20_indices]

print("前20个特征及其对应的mean |SHAP value|值:")
for feature, shap_value in zip(top_20_features, top_20_shap_values):
    print(f"{feature}: {shap_value:.4f}")



# 定义识别化学基团的函数
def identify_chemical_groups(molecule, atom_indices):
    group_set = set()
    
    for idx in atom_indices:
        atom = molecule.GetAtomWithIdx(idx)
        atom_symbol = atom.GetSymbol()
        neighbors = [neighbor.GetSymbol() for neighbor in atom.GetNeighbors()]
        num_neighbors = len(neighbors)
        
        if atom_symbol == 'C':
            if atom.GetIsAromatic():
                group_set.add('Aromatic carbon')
            elif 'O' in neighbors and any(bond.GetBondType() == Chem.rdchem.BondType.DOUBLE for bond in atom.GetBonds()):
                group_set.add('Carbonyl carbon')
            elif any(bond.GetBondType() == Chem.rdchem.BondType.DOUBLE for bond in atom.GetBonds()):
                group_set.add('Alkene carbon')
            elif any(bond.GetBondType() == Chem.rdchem.BondType.TRIPLE for bond in atom.GetBonds()):
                group_set.add('Alkyne carbon')
            elif num_neighbors == 3 and 'H' in neighbors:
                group_set.add('Methyl')
            elif num_neighbors == 2 and 'H' in neighbors:
                group_set.add('Methylene')
            elif num_neighbors == 1 and 'H' in neighbors:
                group_set.add('Methine')
            elif 'N' in neighbors and any(bond.GetBondType() == Chem.rdchem.BondType.TRIPLE for bond in atom.GetBonds()):
                group_set.add('Cyano group')
            else:
                group_set.add('Other carbon')
        
        elif atom_symbol == 'O':
            if 'C' in neighbors and any(bond.GetBondType() == Chem.rdchem.BondType.DOUBLE for bond in atom.GetBonds()):
                group_set.add('Carbonyl oxygen')
            elif 'C' in neighbors and num_neighbors == 1:
                group_set.add('Alcohol OH')
            elif atom.GetIsAromatic():
                group_set.add('Phenolic OH')
            elif 'C' in neighbors and num_neighbors == 2:
                group_set.add('Ether oxygen')
            elif 'O' in neighbors:
                group_set.add('Peroxide')
            else:
                group_set.add('Other oxygen')
        
        elif atom_symbol == 'N':
            if atom.GetIsAromatic():
                group_set.add('Aromatic nitrogen')
            elif num_neighbors in [1, 2, 3]:
                group_set.add('Amine')
            elif 'O' in neighbors and any(bond.GetBondType() == Chem.rdchem.BondType.DOUBLE for bond in atom.GetBonds()):
                group_set.add('Nitroso group')
            elif neighbors.count('O') == 2 and all(bond.GetBondType() == Chem.rdchem.BondType.SINGLE for bond in atom.GetBonds()):
                group_set.add('Nitro group')
            elif 'C' in neighbors and any(bond.GetBondType() == Chem.rdchem.BondType.TRIPLE for bond in atom.GetBonds()):
                group_set.add('Cyano group')
            else:
                group_set.add('Other nitrogen')
        
        elif atom_symbol == 'S':
            if num_neighbors == 1:
                group_set.add('Thiol')
            elif num_neighbors == 2:
                group_set.add('Sulfide')
            elif 'S' in neighbors:
                group_set.add('Disulfide')
            elif any(bond.GetBondType() == Chem.rdchem.BondType.DOUBLE for bond in atom.GetBonds()):
                group_set.add('Sulfoxide')
            elif 'O' in neighbors and len(set(neighbors)) == 3:
                group_set.add('Sulfate ester')
            else:
                group_set.add('Other sulfur')
        
        elif atom_symbol == 'F':
            group_set.add('Fluorine')
        
        elif atom_symbol == 'Cl':
            group_set.add('Chlorine')
        
        elif atom_symbol == 'Br':
            group_set.add('Bromine')
        
        elif atom_symbol == 'I':
            group_set.add('Iodine')
        
        else:
            group_set.add(f'Other {atom_symbol}')
    
    return list(group_set)

# 获取特征对应的原子基团信息
def get_atom_group_info(fp_index, smiles):
    molecule = Chem.MolFromSmiles(smiles)
    if molecule is None:
        return []
    atom_indices = [i for i, bit in enumerate(fingerprint_df.iloc[:, fp_index]) if bit == 1]
    # 过滤掉超出范围的原子索引
    atom_indices = [i for i in atom_indices if i < molecule.GetNumAtoms()]
    return identify_chemical_groups(molecule, atom_indices)

# 映射每个特征的原子基团信息
atom_group_info = {}
for feature in top_20_features:
    try:
        feature_index = int(feature.split('_')[-1])  # 从特征名中提取索引
        # 检查特征索引是否在 che 数据范围内
        if feature_index < len(che):
            smiles = che['Smiles'][feature_index]
            atom_groups = get_atom_group_info(feature_index, smiles)
            atom_group_info[feature] = atom_groups
        else:
            # 处理无效的特征索引
            atom_group_info[feature] = ['Invalid feature index']
    except ValueError:
        atom_group_info[feature] = ['Invalid feature index']

# 打印原子基团信息及其SHAP值
for feature, shap_value in zip(top_20_features, top_20_shap_values):
    print(f"特征 {feature}: 原子基团 {atom_group_info[feature]}, SHAP值: {shap_value:.4f}")




