# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 13:03:26 2024

@author: dell
"""
import shap
from sklearn.preprocessing import StandardScaler, MinMaxScaler, OneHotEncoder
import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.linear_model import BayesianRidge
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.feature_selection import RFE
import numpy as np
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings("ignore")

# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintBayR.csv'
# 从CSV文件中读取数据到DataFrame中
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:, 4:]  # 特征变量：选择所有行，从第4列开始到最后一列
y = che['k'].values.reshape(-1, 1)  # 目标变量：从DataFrame中选择名为'k'的列，重塑为2D数组以适应scaler

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]

# 使用One-Hot编码对类别特征进行处理
encoder = OneHotEncoder(sparse_output=False)
category_feature_encoded = encoder.fit_transform(category_feature.values.reshape(-1, 1))

# 将One-Hot编码后的类别特征转换为DataFrame
category_feature_encoded_df = pd.DataFrame(category_feature_encoded, columns=encoder.get_feature_names_out())

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X.reset_index(drop=True), category_feature_encoded_df.reset_index(drop=True)], axis=1)

# 初始化 MinMaxScaler 对 X 进行归一化处理
scaler = MinMaxScaler()
X_normalized = scaler.fit_transform(X)

# 将归一化后的 X 转换为 DataFrame
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)
X = X_normalized_df

# 标准化数据和目标变量对数变换
scaler = StandardScaler()
y = np.log1p(y)
y = scaler.fit_transform(y)

# 特征选择
bayesian_ridge = BayesianRidge()
n_features_to_select = 500
rfe = RFE(estimator=bayesian_ridge, n_features_to_select=n_features_to_select, step=1)
rfe.fit(X, y.ravel())
selected_features = X.columns[rfe.support_]
X_selected = X[selected_features]

# 分割数据集
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

# 标准化数据
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    bayesian_ridge_regressor_cv = BayesianRidge(
        alpha_1=23.73,
        alpha_2=57.54,
        lambda_1=14.19,
        lambda_2=21.18,
    )
    bayesian_ridge_regressor_cv.fit(X_train_cv, y_train_cv)
    y_pred_cv = bayesian_ridge_regressor_cv.predict(X_val)

    mse_cv = mean_squared_error(y_val, y_pred_cv)
    cv_scores.append(mse_cv)

mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型
X_selected_scaled = scaler.fit_transform(X_selected)
bayesian_ridge_regressor = BayesianRidge(
    alpha_1=23.73,
    alpha_2=57.54,
    lambda_1=14.19,
    lambda_2=21.18,
)
bayesian_ridge_regressor.fit(X_selected_scaled, y)

# 对每个类别分别进行预测和评估
category_results = {}

for i, category in enumerate(encoder.categories_[0]):
    category_idx = category_feature_encoded_df.iloc[:, i] == 1
    X_category = X_selected[category_idx]
    y_category = y[category_idx]
    
    X_category_scaled = scaler.transform(X_category)
    
    y_pred_category = bayesian_ridge_regressor.predict(X_category_scaled)
    
    mse_category = mean_squared_error(y_category, y_pred_category)
    rmse_category = np.sqrt(mse_category)
    mae_category = mean_absolute_error(y_category, y_pred_category)
    r2_category = r2_score(y_category, y_pred_category)
    
    # 计算 MAE 百分比（假设基准值为 y_category 的均值）
    mae_percentage = (mae_category / np.mean(y_category)) * 100
    
    category_results[category] = {
        'MSE': mse_category,
        'RMSE': rmse_category,
        'MAE (%)': mae_percentage,
        'R²': r2_category
    }

# 获取类别、R²和RMSE值
categories = list(category_results.keys())
r2_values = [metrics['R²'] for metrics in category_results.values()]
rmse_values = [metrics['RMSE'] for metrics in category_results.values()]

import matplotlib.pyplot as plt
import numpy as np

# 生成字母映射
alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
category_labels = {i: alphabet[i % 26] + (str(i // 26 + 1) if i >= 26 else '') for i in range(len(categories))}
mapped_categories = [category_labels[i] for i in range(len(categories))]

# 1.绘制R²折线图
plt.figure(figsize=(12, 8))

# 绘制主图
plt.plot(mapped_categories, r2_values, marker='o', linestyle='-', color='b', label='R²', markersize=8)
plt.xlabel('Chemical Classes')
plt.ylabel('R²')
plt.xticks(ha='right', fontsize=12)
plt.grid(True, which='both', axis='both', linestyle='-', linewidth=0.5, color='gray')

# 绘制嵌套图
ax_inset = plt.axes([0.5, 0.35, 0.375, 0.3])
ax_inset.plot(mapped_categories, rmse_values, marker='x', linestyle='--', color='r', markersize=8)
ax_inset.set_xlabel('')  # 去掉X轴标题
ax_inset.set_ylabel('RMSE')
ax_inset.grid(True, which='both', axis='both', linestyle='-', linewidth=0.5, color='gray')

# 调整嵌套图的X轴标签以避免重叠
ax_inset.set_xticks(mapped_categories[::2])  # 每隔一个标签显示一次，增加间距
ax_inset.tick_params(axis='x', rotation=45, labelsize=8)
ax_inset.tick_params(axis='y', labelsize=8)

# 自动调整布局
plt.tight_layout()
plt.show()


import matplotlib.pyplot as plt
import numpy as np

# 2.计算填充比例
r2_filled = r2_values / np.max(r2_values)
rmse_filled = rmse_values / np.max(rmse_values)

# 设置固定的扇区大小
num_categories = len(categories)
theta = np.linspace(0, 2 * np.pi, num_categories + 1)

# 绘制单独展示 R² 的饼状图
plt.figure(figsize=(10, 8))
ax = plt.subplot(111, projection='polar')
ax.set_facecolor('white')  # 设置背景颜色为白色
bars = ax.bar(theta[:-1], r2_filled, width=np.pi * 2 / num_categories, bottom=0.0, alpha=0.8, edgecolor='black')

for bar in bars:
    bar.set_facecolor('magenta')  # 设置填充颜色为洋红

ax.set_xticks(theta[:-1])
ax.set_xticklabels(mapped_categories, rotation=45, ha='right', fontsize=10)
ax.set_yticklabels([])
plt.show()

# 绘制单独展示 RMSE 的饼状图
plt.figure(figsize=(10, 8))
ax = plt.subplot(111, projection='polar')
ax.set_facecolor('white')  # 设置背景颜色为白色
bars = ax.bar(theta[:-1], rmse_filled, width=np.pi * 2 / num_categories, bottom=0.0, alpha=0.8, edgecolor='black')

for bar in bars:
    bar.set_facecolor('cyan')  # 设置填充颜色为青色

ax.set_xticks(theta[:-1])
ax.set_xticklabels(mapped_categories, rotation=45, ha='right', fontsize=10)
ax.set_yticklabels([])
plt.show()

# 使用 KernelExplainer 计算 SHAP 值
explainer = shap.KernelExplainer(bayesian_ridge_regressor.predict, X_train_scaled[:100])  # 选择一部分训练数据作为背景数据
shap_values = explainer.shap_values(X_test_scaled)

# 绘制 SHAP summary plot
shap.summary_plot(shap_values, X_test_scaled, feature_names=selected_features)


