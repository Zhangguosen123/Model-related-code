# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 16:36:33 2024

@author: dell
"""
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import warnings

warnings.filterwarnings("ignore")

# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintMLP.csv'
# 从CSV文件中读取数据到DataFrame中
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
# 特征变量：选择所有行，从第4列开始到最后一列
X = che.iloc[:, 4:]
# 目标变量：从DataFrame中选择名为'k'的列，重塑为2D数组以适应scaler
y = che['k'].values.reshape(-1, 1)

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]
# 将类别特征转换成数字编码（0 到 26）
category_feature_encoded = category_feature.replace({
    'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
    'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
    'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
    'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26})

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X, category_feature_encoded], axis=1)

# 初始化 MinMaxScaler，对 X 进行归一化处理
scaler = MinMaxScaler()
X_normalized = scaler.fit_transform(X)
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)
X = X_normalized_df

# 对目标变量进行对数变换
y = np.log1p(y)

# 初始化 MinMaxScaler，对目标变量进行归一化
scaler_y = MinMaxScaler()
y_normalized = scaler_y.fit_transform(y)

# 定义最佳超参数值
best_num_layers = 9   
best_num_neurons = 657
best_learning_rate = 0.0096

# 创建多层感知机模型
model = Sequential()
model.add(Dense(best_num_neurons, activation='relu', input_shape=(X.shape[1],)))
for _ in range(best_num_layers):
    model.add(Dense(best_num_neurons, activation='relu'))
model.add(Dense(1))  # 输出层

# 编译模型，选择优化器和损失函数
model.compile(optimizer='adam', loss='mean_squared_error')

# 将数据分割为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y_normalized, test_size=0.2, random_state=42)

# 训练模型
history = model.fit(X_train, y_train, validation_split=0.2, epochs=1000, batch_size=60, verbose=1)

# 评估模型在测试集上的性能
test_loss = model.evaluate(X_test, y_test)
print('Test Loss:', test_loss)

# 在训练集上进行预测
y_pred_train = model.predict(X_train)

# 在测试集上进行预测
y_pred_test = model.predict(X_test)

# 计算和打印均方误差（MSE）for训练集和测试集
mse_train = mean_squared_error(y_train, y_pred_train)
mse_test = mean_squared_error(y_test, y_pred_test)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for测试集
rmse_train = np.sqrt(mse_train)
rmse_test = np.sqrt(mse_test)
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

# 计算R平方（R2）for训练集
r2_train = r2_score(y_train, y_pred_train)
print(f"训练集R平方（R2）: {r2_train:.4f}")

# 计算R平方（R2）for测试集
r2_test = r2_score(y_test, y_pred_test)
print(f"测试集R平方（R2）: {r2_test:.4f}")


