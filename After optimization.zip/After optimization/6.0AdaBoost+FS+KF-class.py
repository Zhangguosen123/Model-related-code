# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 13:56:39 2024

@author: dell
"""
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.ensemble import AdaBoostRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.svm import SVR
from sklearn.feature_selection import RFE
import numpy as np
import warnings

warnings.filterwarnings("ignore")

# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintAda.csv'
# 从CSV文件中读取数据到DataFrame中
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
# 特征变量：选择所有行，从第4列开始到最后一列
X = che.iloc[:, 4:]
# 目标变量：从DataFrame中选择名为'k'的列，重塑为2D数组以适应scaler
y = che['k'].values.reshape(-1, 1)

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]
# 将类别特征转换成数字编码（0 到 26）
category_feature_encoded = category_feature.replace({
    'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
    'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
    'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
    'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26})

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X, category_feature_encoded], axis=1)

# 初始化 MinMaxScaler
scaler = MinMaxScaler()

# 对 X 进行归一化处理
X_normalized = scaler.fit_transform(X)

# 将归一化后的 X 转换为 DataFrame
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)

X = X_normalized_df
# 标准化数据
scaler = StandardScaler()
# 对目标变量进行对数变换
y = np.log1p(y)
# 对目标变量进行归一化
y = scaler.fit_transform(y)

# 特征选择
# 创建支持向量机回归模型
svm = SVR(kernel='linear')
# 使用递归特征消除（RFE）进行特征选择
n_features_to_select = 500
rfe = RFE(estimator=svm, n_features_to_select=n_features_to_select, step=1)
# 在全量数据上进行特征选择
rfe.fit(X, y.ravel())  # ravel()将y变成1维数组，符合RFE的输入要求
# 提取选择后的特征
selected_features = X.columns[rfe.support_]
# 根据选择的特征重新准备数据
X_selected = X[selected_features]

# 将数据分割为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

# 标准化数据（如果需要）
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 使用K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# 初始化空列表，用于存储每次交叉验证的性能指标
cv_scores = []

# 在每个交叉验证折上进行训练和评估
for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    # 创建并训练AdaBoost回归器
    ada_regressor_cv = AdaBoostRegressor(
        n_estimators=1654,
        random_state=42
    )
    ada_regressor_cv.fit(X_train_cv, y_train_cv)

    # 在验证集上进行预测
    y_pred_cv = ada_regressor_cv.predict(X_val)

    # 计算均方误差（MSE）
    mse_cv = mean_squared_error(y_val, y_pred_cv)

    # 将MSE存储到列表中
    cv_scores.append(mse_cv)

# 计算交叉验证的均值和标准差
mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型（使用全部训练数据）
# 标准化所有训练数据
X_selected_scaled = scaler.fit_transform(X_selected)
# 创建并训练最终的AdaBoost回归器
ada_regressor = AdaBoostRegressor(
    n_estimators=1654,
    random_state=42
)
ada_regressor.fit(X_selected_scaled, y)

# 在训练集上进行预测
y_pred_train = ada_regressor.predict(X_selected_scaled)

# 在测试集上进行预测（记得也要用选择后的特征）
X_test_selected = X_test[selected_features]
X_test_selected_scaled = scaler.transform(X_test_selected)
y_pred_test = ada_regressor.predict(X_test_selected_scaled)

# 计算和打印均方误差（MSE）for训练集和测试集
mse_train = mean_squared_error(y, y_pred_train)
mse_test = mean_squared_error(y_test, y_pred_test)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")

# 计算和打印均方根误差（RMSE）for测试集
rmse_train = np.sqrt(mse_train)
rmse_test = np.sqrt(mse_test)
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

# 计算R平方（R2）for训练集
r2_train = r2_score(y, y_pred_train)
print(f"训练集R平方（R2）: {r2_train:.4f}")
# 计算R平方（R2）for测试集
r2_test = r2_score(y_test, y_pred_test)
print(f"测试集R平方（R2）: {r2_test:.4f}")

