# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 10:28:58 2024

@author: dell
"""
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import xgboost as xgb
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import StandardScaler
from rdkit import Chem
from rdkit.Chem import AllChem
from bayes_opt import BayesianOptimization
import warnings

warnings.filterwarnings("ignore")

def xgb_model(fp_size, radius, n_estimators, max_depth, min_child_weight, gamma):
    def smiles_to_fingerprint(smiles, fp_size=int(fp_size)):
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is not None:
            fingerprint = AllChem.GetMorganFingerprintAsBitVect(molecule, radius=int(radius), nBits=fp_size)
            return np.array(fingerprint, dtype=int)
        else:
            return [np.nan] * fp_size

    filename = 'H:/Pythoncodes/1/add class/OH-SMILESClass0.csv'
    che = pd.read_csv(filename, header=0)

    fingerprints = [smiles_to_fingerprint(smiles) for smiles in che['Smiles']]
    fingerprint_df = pd.DataFrame(fingerprints)

    che_fingerprint = pd.concat([che, fingerprint_df], axis=1)
    che = che_fingerprint

    X = che.iloc[:, 4:]
    y = che['k'].values.reshape(-1, 1)

    category_feature = che.iloc[:, 2]
    category_feature_encoded = category_feature.replace({
        'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
        'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
        'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
        'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26}).to_frame()

    scaler = MinMaxScaler()
    category_feature_normalized = scaler.fit_transform(category_feature_encoded.values.reshape(-1, 1))
    X_normalized = scaler.fit_transform(X)

    X_normalized_df = pd.DataFrame(X_normalized, columns=[f"num_feat_{i}" for i in range(X_normalized.shape[1])])
    category_feature_normalized_df = pd.DataFrame(category_feature_normalized, columns=["category_feature"])

    X = pd.concat([X_normalized_df, category_feature_normalized_df], axis=1)

    X.columns = [f"feature_{i}" for i in range(X.shape[1])]

    scaler = StandardScaler()
    y = np.log1p(y)
    y = scaler.fit_transform(y)

    X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=42)

    xgb_regressor = xgb.XGBRegressor(
        n_estimators=int(n_estimators),
        max_depth=int(max_depth),
        min_child_weight=int(min_child_weight),
        gamma=float(gamma),
        learning_rate=0.05,
        random_state=42
    )
    xgb_regressor.fit(X_train, y_train_scaled)

    y_pred = xgb_regressor.predict(X_test)

    mse_test = mean_squared_error(y_test_scaled, y_pred)
    rmse_test = np.sqrt(mse_test)
    r2_test = r2_score(y_test_scaled, y_pred)
    print(f"测试集R平方（R2）: {r2_test:.4f}")
    return r2_test

# 定义超参数搜索空间
search_space = {
    'fp_size': (16, 12288),
    'radius': (1, 16),
    'n_estimators': (10, 3000),  # 调整为合适的范围，例如(10, 200)
    'max_depth': (1, 64),
    'min_child_weight': (1, 10),
    'gamma': (0, 1)  # 添加gamma的范围
}

# Bayesian优化器的初始化
opt = BayesianOptimization(
    xgb_model,
    search_space,
    random_state=42
)

# 进行优化，设置迭代次数
opt.maximize(n_iter=300)

# 获取最佳参数与最佳分数
params_best = opt.max["params"]
score_best = opt.max["target"]

# 打印最佳参数与最佳分数
print("\n", "\n", "best params: ", params_best,
      "\n", "\n", "best cvscore: ", score_best)

