"""
Created on Wed Aug 21 10:51:36 2024

@author: dell
"""
import shap
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import pandas as pd
from sklearn.model_selection import train_test_split, KFold
from sklearn.linear_model import BayesianRidge
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.feature_selection import RFE
import numpy as np
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings("ignore")

# 文件路径
filename = 'H:/Pythoncodes/1/add class/OH-FringerprintBayR.csv'
# 从CSV文件中读取数据到DataFrame中
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:, 4:]  # 特征变量：选择所有行，从第4列开始到最后一列
y = che['k'].values.reshape(-1, 1)  # 目标变量：从DataFrame中选择名为'k'的列，重塑为2D数组以适应scaler

# 处理类别特征列（假设类别特征在第二列）
category_feature = che.iloc[:, 2]
category_mapping = {
    'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
    'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
    'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
    'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26
}
category_feature_encoded = category_feature.replace(category_mapping)

# 将编码后的类别特征加入到特征变量 X 中
X = pd.concat([X, category_feature_encoded], axis=1)

# 初始化 MinMaxScaler 对 X 进行归一化处理
scaler = MinMaxScaler()
X_normalized = scaler.fit_transform(X)

# 将归一化后的 X 转换为 DataFrame
X_normalized_df = pd.DataFrame(X_normalized, columns=X.columns)
X = X_normalized_df

# 标准化数据和目标变量对数变换
scaler = StandardScaler()
y = np.log1p(y)
y = scaler.fit_transform(y)

# 特征选择
bayesian_ridge = BayesianRidge()
n_features_to_select = 500
rfe = RFE(estimator=bayesian_ridge, n_features_to_select=n_features_to_select, step=1)
rfe.fit(X, y.ravel())
selected_features = X.columns[rfe.support_]
X_selected = X[selected_features]

# 分割数据集
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

# 标准化数据
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    bayesian_ridge_regressor_cv = BayesianRidge(
        alpha_1=23.73,
        alpha_2=57.54,
        lambda_1=14.19,
        lambda_2=21.18,
    )
    bayesian_ridge_regressor_cv.fit(X_train_cv, y_train_cv)
    y_pred_cv = bayesian_ridge_regressor_cv.predict(X_val)

    mse_cv = mean_squared_error(y_val, y_pred_cv)
    cv_scores.append(mse_cv)

mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型
X_selected_scaled = scaler.fit_transform(X_selected)
bayesian_ridge_regressor = BayesianRidge(
    alpha_1=23.73,
    alpha_2=57.54,
    lambda_1=14.19,
    lambda_2=21.18,
)
bayesian_ridge_regressor.fit(X_selected_scaled, y)

# 对每个类别分别进行预测和评估
category_results = {}

for category in category_feature_encoded.unique():
    category_idx = category_feature_encoded == category
    X_category = X_selected[category_idx]
    y_category = y[category_idx]
    
    X_category_scaled = scaler.transform(X_category)
    
    y_pred_category = bayesian_ridge_regressor.predict(X_category_scaled)
    
    mse_category = mean_squared_error(y_category, y_pred_category)
    rmse_category = np.sqrt(mse_category)
    mae_category = mean_absolute_error(y_category, y_pred_category)
    r2_category = r2_score(y_category, y_pred_category)
    
    # 计算 MAE 百分比（假设基准值为 y_category 的均值）
    mae_percentage = (mae_category / np.mean(y_category)) * 100
    
    category_results[category] = {
        'MSE': mse_category,
        'RMSE': rmse_category,
        'MAE (%)': mae_percentage,
        'R²': r2_category
    }

# 将类别映射回实际名称
category_names = {v: k for k, v in category_mapping.items()}
categories = [category_names[category] for category in category_results.keys()]

# 获取R2和RMSE值
r2_values = [metrics['R²'] for metrics in category_results.values()]
rmse_values = [metrics['RMSE'] for metrics in category_results.values()]

import matplotlib.pyplot as plt
import numpy as np


# 生成字母映射
alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
category_labels = {i: alphabet[i % 26] + (str(i // 26 + 1) if i >= 26 else '') for i in range(len(categories))}
mapped_categories = [category_labels[i] for i in range(len(categories))]

# 1. 绘制 R² 折线图
plt.figure(figsize=(12, 8))

# 绘制主图
plt.plot(mapped_categories, r2_values, marker='o', linestyle='-', color='b', label='R²', markersize=8)
plt.xlabel('Chemical Classes')
plt.ylabel('R²')
plt.xticks(fontsize=12)  # X轴标签字体大小
plt.grid(True, which='both', axis='both', linestyle='-', linewidth=0.5, color='gray')

# 绘制嵌套图
ax_inset = plt.axes([0.5, 0.30, 0.375, 0.3])
ax_inset.plot(mapped_categories, rmse_values, marker='x', linestyle='--', color='r', markersize=8)
ax_inset.set_xlabel('')  # 去掉X轴标题
ax_inset.set_ylabel('RMSE')
ax_inset.grid(True, which='both', axis='both', linestyle='-', linewidth=0.5, color='gray')

# 调整嵌套图的 X 轴标签设置
ax_inset.set_xticks(mapped_categories)  # 显示所有 X 轴标签
ax_inset.tick_params(axis='x', labelsize=8)  # 设置 X 轴标签字体大小
ax_inset.tick_params(axis='y', labelsize=8)  # 设置 Y 轴标签字体大小

# 自动调整布局
plt.tight_layout()
plt.show()


import matplotlib.pyplot as plt
import numpy as np

# 生成字母映射
alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
category_labels = {i: alphabet[i % 26] + (str(i // 26 + 1) if i >= 26 else '') for i in range(len(categories))}
mapped_categories = [category_labels[i] for i in range(len(categories))]

# 计算R²和RMSE的均值
mean_r2 = np.mean(r2_values)
mean_rmse = np.mean(rmse_values)

# 1. 绘制R²折线图
plt.figure(figsize=(12, 6))
plt.plot(mapped_categories, r2_values, marker='o', linestyle='-', color='b', label='R²', markersize=8)
plt.axhline(y=0.9, color='darkblue', linestyle='--', label='R² = 0.9')  # 添加R²界限线
plt.ylim(min(r2_values) - 0.1, max(r2_values) + 0.1)  # 设置y轴范围根据实际值调整
plt.xlabel('Chemical Classes')
plt.ylabel('R²')
plt.xticks(rotation=0, ha='center', fontsize=12)  # x轴标签不倾斜
plt.yticks(fontsize=12)
plt.grid(True, which='both', axis='both', linestyle='-', linewidth=0.5, color='gray')
plt.legend()
plt.tight_layout()

# 2. 绘制RMSE折线图
plt.figure(figsize=(12, 6))
plt.plot(mapped_categories, rmse_values, marker='s', linestyle='-', color='r', label='RMSE', markersize=8)
plt.axhline(y=0.10, color='darkred', linestyle='--', label='RMSE = 0.10')  # 添加RMSE界限线
plt.ylim(min(rmse_values) - 0.01, max(rmse_values) + 0.01)  # 设置y轴范围根据实际值调整
plt.xlabel('Chemical Classes')
plt.ylabel('RMSE')
plt.xticks(rotation=0, ha='center', fontsize=12)  # x轴标签不倾斜
plt.yticks(fontsize=12)
plt.grid(True, which='both', axis='both', linestyle='-', linewidth=0.5, color='gray')
plt.legend()
plt.tight_layout()

plt.show()

import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl

# 生成字母映射
alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
category_labels = {i: alphabet[i % 26] + (str(i // 26 + 1) if i >= 26 else '') for i in range(len(categories))}
mapped_categories = [category_labels[i] for i in range(len(categories))]

# 计算R²和RMSE的均值
mean_r2 = np.mean(r2_values)
mean_rmse = np.mean(rmse_values)

# 设置matplotlib输出的PDF为Illustrator可编辑的字体
mpl.rcParams['pdf.fonttype'] = 42

# 设置保存路径
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\ML：氧化剂与污染物降解\模型结果图-tif和eps'

# 1. 绘制R²折线图并保存为PDF
plt.figure(figsize=(12, 6))
plt.plot(mapped_categories, r2_values, marker='o', linestyle='-', color='b', label='R²', markersize=8)
plt.axhline(y=0.9, color='darkblue', linestyle='--', label='R² = 0.9')  # 添加R²界限线

# 控制y轴范围：最小值根据实际值调整，最大值为1.0
plt.ylim(min(r2_values) - 0.05, 1.03)

plt.xlabel('Chemical Classes')
plt.ylabel('R²')
plt.xticks(rotation=0, ha='center', fontsize=12)  # x轴标签不倾斜
plt.yticks(fontsize=12)
plt.grid(True, which='both', axis='both', linestyle='-', linewidth=0.5, color='gray')
plt.legend()
plt.tight_layout()
plt.savefig(f'{save_path}\\r2_plot.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

# 2. 绘制RMSE折线图并保存为PDF
plt.figure(figsize=(12, 6))
plt.plot(mapped_categories, rmse_values, marker='s', linestyle='-', color='r', label='RMSE', markersize=8)
plt.axhline(y=0.10, color='darkred', linestyle='--', label='RMSE = 0.10')  # 添加RMSE界限线
plt.ylim(min(rmse_values) - 0.01, max(rmse_values) + 0.01)  # 设置y轴范围根据实际值调整
plt.xlabel('Chemical Classes')
plt.ylabel('RMSE')
plt.xticks(rotation=0, ha='center', fontsize=12)  # x轴标签不倾斜
plt.yticks(fontsize=12)
plt.grid(True, which='both', axis='both', linestyle='-', linewidth=0.5, color='gray')
plt.legend()
plt.tight_layout()
plt.savefig(f'{save_path}\\rmse_plot.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

# from sklearn.inspection import permutation_importance

# # 使用排列重要性方法获取特征重要性
# result = permutation_importance(
#     bayesian_ridge_regressor, 
#     X_selected_scaled, 
#     y, 
#     n_repeats=10, 
#     random_state=42, 
#     scoring='neg_mean_squared_error'
# )

# # 获取重要性并排序
# importances = result.importances_mean
# importance_df = pd.DataFrame({
#     '特征': X_selected.columns,
#     '重要性': importances
# }).sort_values(by='重要性', ascending=False)

# # 输出特征重要性排名
# print("特征重要性排名:")
# print(importance_df)

# import matplotlib.pyplot as plt
# from sklearn.inspection import PartialDependenceDisplay

# # 选择前4个重要的特征
# top_features = importance_df.head(4)['特征'].values

# # 为前4个特征的所有特征对生成2D PDP
# for i in range(len(top_features)):
#     for j in range(i + 1, len(top_features)):
#         feature1 = top_features[i]
#         feature2 = top_features[j]
        
#         fig, ax = plt.subplots(figsize=(12, 8))
#         pdp = PartialDependenceDisplay.from_estimator(
#             bayesian_ridge_regressor, 
#             X_selected_scaled,
#             features=[feature1, feature2],
#             ax=ax,
#             grid_resolution=50
#         )
        
#         plt.title(f'2D 部分依赖图: {feature1} 与 {feature2}')
#         plt.xlabel(feature1)
#         plt.ylabel(feature2)
#         plt.tight_layout()
#         plt.show()

# from sklearn.cluster import KMeans
# from sklearn.decomposition import PCA

# # 对类别特征进行聚类分析
# n_clusters = 5  # 假设分为5个簇，可以根据需要调整
# kmeans = KMeans(n_clusters=n_clusters, random_state=42)
# clusters = kmeans.fit_predict(X_selected_scaled)

# # 使用PCA进行可视化
# pca = PCA(n_components=2)  # 将高维数据降到2D进行可视化
# X_pca = pca.fit_transform(X_selected_scaled)

# plt.figure(figsize=(10, 8))
# plt.scatter(X_pca[:, 0], X_pca[:, 1], c=clusters, cmap='viridis', s=50, alpha=0.6)
# plt.colorbar(label='Cluster')
# plt.xlabel('PCA Component 1')
# plt.ylabel('PCA Component 2')
# plt.title('Cluster Analysis of Category Features')
# plt.grid(True)
# plt.show()

# # 输出聚类结果
# clustered_categories = pd.DataFrame({
#     'Category': mapped_categories,
#     'Cluster': clusters
# })
# print(clustered_categories.sort_values('Cluster'))



# import matplotlib.pyplot as plt
# import numpy as np

# # 3.计算填充比例
# r2_filled = r2_values / np.max(r2_values)
# rmse_filled = rmse_values / np.max(rmse_values)

# # 设置固定的扇区大小
# num_categories = len(categories)
# theta = np.linspace(0, 2 * np.pi, num_categories + 1)

# # 绘制单独展示 R² 的饼状图
# plt.figure(figsize=(10, 8))
# ax = plt.subplot(111, projection='polar')
# ax.set_facecolor('white')  # 设置背景颜色为白色
# bars = ax.bar(theta[:-1], r2_filled, width=np.pi * 2 / num_categories, bottom=0.0, alpha=0.8, edgecolor='black')

# for bar in bars:
#     bar.set_facecolor('magenta')  # 设置填充颜色为洋红

# ax.set_xticks(theta[:-1])
# ax.set_xticklabels(mapped_categories, rotation=45, ha='right', fontsize=10)
# ax.set_yticklabels([])
# # ax.set_title("R² 饼状图", fontsize=15)
# plt.show()

# # 绘制单独展示 RMSE 的饼状图
# plt.figure(figsize=(10, 8))
# ax = plt.subplot(111, projection='polar')
# ax.set_facecolor('white')  # 设置背景颜色为白色
# bars = ax.bar(theta[:-1], rmse_filled, width=np.pi * 2 / num_categories, bottom=0.0, alpha=0.8, edgecolor='black')

# for bar in bars:
#     bar.set_facecolor('cyan')  # 设置填充颜色为青色

# ax.set_xticks(theta[:-1])
# ax.set_xticklabels(mapped_categories, rotation=45, ha='right', fontsize=10)
# ax.set_yticklabels([])
# # ax.set_title("RMSE 饼状图", fontsize=15)
# plt.show()

# # 绘制 R² 和 RMSE 的双层饼状图
# plt.figure(figsize=(10, 8))
# ax = plt.subplot(111, projection='polar')
# ax.set_facecolor('white')  # 设置背景颜色为白色

# # 外层饼图 (R²)
# bars_outer = ax.bar(theta[:-1], r2_filled, width=np.pi * 2 / num_categories, bottom=0.5, alpha=0.8, edgecolor='black')
# for bar in bars_outer:
#     bar.set_facecolor('magenta')  # 设置填充颜色为洋红

# # 内层饼图 (RMSE)
# bars_inner = ax.bar(theta[:-1], rmse_filled, width=np.pi * 2 / num_categories, bottom=0.0, alpha=0.8, edgecolor='black')
# for bar in bars_inner:
#     bar.set_facecolor('cyan')  # 设置填充颜色为青色

# ax.set_xticks(theta[:-1])
# ax.set_xticklabels(mapped_categories, rotation=45, ha='right', fontsize=10)
# ax.set_yticklabels([])
# # ax.set_title("R² 和 RMSE 双层饼状图", fontsize=15)
# plt.show()


# from sklearn.inspection import partial_dependence, PartialDependenceDisplay

# # Select top features to plot
# n_features_to_plot = 3
# top_features = selected_features[:n_features_to_plot]

# # Ensure features exist in X_selected
# print("Top Features:", top_features)
# print("X_selected Columns:", X_selected.columns)

# # Plot Partial Dependence for each category
# for idx, category in enumerate(category_feature_encoded.unique()):
#     # Select data for the current category
#     category_idx = category_feature_encoded == category
#     X_category = X_selected.loc[category_idx]
#     y_category = y[category_idx]

#     # Skip if no data for this category
#     if X_category.shape[0] == 0:
#         continue

#     # Standardize data
#     X_category_scaled = scaler.transform(X_category)

#     # Verify features exist in the standardized data
#     valid_features = [feat for feat in top_features if feat in X_selected.columns]

#     # Plot PDP if valid features exist
#     if valid_features:
#         display = PartialDependenceDisplay.from_estimator(
#             bayesian_ridge_regressor,
#             X_category_scaled,
#             features=valid_features,
#             kind='both',  # Display both ICE and PDP
#             grid_resolution=50
#         )

#         plt.suptitle(f'PDP for Category: {category_names[category]}')
#         plt.subplots_adjust(top=0.9)  # Adjust title position
#         plt.show()
#     else:
#         print(f"No valid features found for category {category_names[category]}. Skipping PDP.")

