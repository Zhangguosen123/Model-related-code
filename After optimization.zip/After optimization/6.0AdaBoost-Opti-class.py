# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 14:06:37 2024

@author: dell
"""
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostRegressor
from sklearn.metrics import r2_score, mean_squared_error
from rdkit import Chem
from rdkit.Chem import AllChem
from bayes_opt import BayesianOptimization
import warnings

warnings.filterwarnings("ignore")

def ada(fp_size, radius, n_estimators):
    # 定义一个函数，用于将 SMILES 字符串转换为分子指纹
    def smiles_to_fingerprint(smiles, fp_size=int(fp_size)):
        # 定义一个函数，将SMILES表示的分子转换为指纹，默认指纹大小为1024位
        molecule = Chem.MolFromSmiles(smiles)  # 将 SMILES 字符串转换为分子对象
        if molecule is not None:  # 确保SMILES字符串有效
            fingerprint = AllChem.GetMorganFingerprintAsBitVect(molecule, radius=int(radius), nBits=fp_size)
            # 使用 Morgan 指纹方法生成分子指纹
            return np.array(fingerprint, dtype=int)
            # 将指纹转换为 numpy 数组并返回，确保数据类型为整型
        else:
            return [np.nan] * fp_size  # 对于无效的SMILES字符串返回包含NaN的列表

    # 读取CSV文件并创建DataFrame对象
    filename = 'H:/Pythoncodes/1/add class/OH-SMILESClass0.csv'  # 文件路径
    che = pd.read_csv(filename, header=0)

    # 应用函数并创建一个新的DataFrame来存储分子指纹
    fingerprints = [smiles_to_fingerprint(smiles) for smiles in che['Smiles']]
    fingerprint_df = pd.DataFrame(fingerprints)

    # 如果你想要在同一个DataFrame中保留原始的SMILES字符串和分子指纹，可以这样做：
    che_fingerprint = pd.concat([che, fingerprint_df], axis=1)

    che = che_fingerprint  # 更新DataFrame为包含分子指纹的数据

    # 分离特征和目标变量
    X = che.iloc[:, 4:]
    y = che['k'].values.reshape(-1, 1)

    # 处理类别特征列（假设类别特征在第三列）
    category_feature = che.iloc[:, 2]
    category_feature_encoded = category_feature.replace({
        'alkane': 0, 'alcohol': 1, 'diol': 2, 'ether': 3, 'ketone': 4, 'aldehyde': 5, 'ester': 6, 'carboxyl': 7,
        'dicarboxylic': 8, 'halogeneted': 9, 'sulfide, disulfide': 10, 'sulfoxide': 11, 'thiol': 12, 'nitrile': 13,
        'nitro': 14, 'amide': 15, 'amine': 16, 'nitroso, nitramine': 17, 'phosphorus': 18, 'cyclo': 19, 'alkene': 20,
        'benzene': 21, 'pyridine': 22, 'furan': 23, 'urea': 24, 'imidazole': 25, 'triazine': 26}).to_frame()

    # 初始化 MinMaxScaler
    scaler = MinMaxScaler()

    # 对类别特征进行归一化
    category_feature_normalized = scaler.fit_transform(category_feature_encoded.values.reshape(-1, 1))

    # 对数值特征进行归一化
    X_normalized = scaler.fit_transform(X)

    # 将归一化后的类别特征和数值特征合并到特征变量 X 中
    X = pd.concat([pd.DataFrame(X_normalized), pd.DataFrame(category_feature_normalized)], axis=1)

    # 转换所有列名为字符串类型，确保列名的一致性 
    X.columns = X.columns.astype(str)

    # 标准化数据
    scaler = StandardScaler()
    y = np.log1p(y)
    y = scaler.fit_transform(y)

    X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=42)
    # 分割数据为训练集和测试集

    ada_regressor = AdaBoostRegressor(  # 设置AdaBoost回归器的参数
        n_estimators=int(n_estimators),  # 基学习器的数量
        random_state=42  # 随机种子，保证结果可重复
    )
    # 训练模型
    ada_regressor.fit(X_train, y_train_scaled)

    # 预测测试集
    y_pred = ada_regressor.predict(X_test)

    # 计算和打印均方误差（MSE）和均方根误差（RMSE）for测试集
    mse_test = mean_squared_error(y_test_scaled, y_pred)
    rmse_test = np.sqrt(mse_test)
    # 计算R平方（R2）for测试集
    r2_test = r2_score(y_test_scaled, y_pred)
    print(f"测试集R平方（R2）: {r2_test:.4f}")
    return r2_test

# 定义超参数搜索空间
search_space = {
    'fp_size': (16, 12288),
    'radius': (1, 16),
    'n_estimators': (10, 3000)  # 仅搜索AdaBoost的n_estimators
}

# Bayesian优化器的初始化
opt = BayesianOptimization(
    ada,
    search_space,
    random_state=42
)

# 进行优化，设置迭代次数
opt.maximize(n_iter=300)

# 获取最佳参数与最佳分数
params_best = opt.max["params"]
score_best = opt.max["target"]

# 打印最佳参数与最佳分数
print("\n", "\n", "best params: ", params_best,
      "\n", "\n", "best cvscore: ", score_best)

