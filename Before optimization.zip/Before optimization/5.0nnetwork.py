# -*- coding: utf-8 -*-
"""
Created on Sat May 11 19:16:35 2024

@author: dell
"""

import numpy as np # 导入NumPy库，用于数值计算
import tensorflow as tf # 导入TensorFlow库
from tensorflow.keras.models import Sequential # 导入Sequential模型，用于搭建神经网络模型
from tensorflow.keras.layers import Dense # 导入Dense层，用于定义全连接层
from sklearn.model_selection import train_test_split # 导入train_test_split函数，用于将数据集分割为训练集和测试集
from sklearn.preprocessing import StandardScaler  # 导入标准化器，用于对数据进行标准化处理
import pandas as pd # 导入Pandas库，用于数据处理和分析
from sklearn.metrics import mean_squared_error # 导入均方误差函数
from sklearn.metrics import r2_score # 导入R平方函数

# 假设che是你的DataFrame，并且它已经包含了1024个分子指纹的列和一个名为'k'的列
filename = 'H:/Pythoncodes/1/OH-FringerprintMLP.csv' # 文件路径
che = pd.read_csv(filename, header=0) 
# 分离特征和目标变量
X = che.iloc[:,3:] # 特征：除去第4列之后的所有列
y = che['k'].values.reshape(-1, 1)  # 目标变量：k列，重塑为2D数组以适应scaler

scaler = StandardScaler() # 初始化StandardScaler

y_scaled = np.log1p(y) # 对目标变量进行对数变换

y_scaled = scaler.fit_transform(y_scaled) # 对目标变量进行归一化

X_train, X_test, y_train, y_test = train_test_split(X, y_scaled, test_size=0.2, random_state=42)
# 分割数据为训练集和测试集

# 特征标准化
# scaler = StandardScaler()
# X_train_scaled = scaler.fit_transform(X_train)
# X_test_scaled = scaler.transform(X_test)

# 定义神经网络模型
model = Sequential([
    Dense(128, activation='relu', input_shape=(X_train.shape[1],)), # 输入层，128个神经元，ReLU激活函数
    Dense(640, activation='relu'), # 隐藏层，640个神经元，ReLU激活函数
    Dense(640, activation='relu'), # 隐藏层，640个神经元，ReLU激活函数
    Dense(1) # 输出层，一个神经元
])

# 编译模型，选择优化器和损失函数
model.compile(optimizer='adam', loss='mean_squared_error')

# 训练模型
history = model.fit(X_train, y_train, validation_split=0.2, epochs=1000, batch_size=60)

# 评估模型在测试集上的性能
test_loss = model.evaluate(X_test, y_test)
print('Test Loss:', test_loss)

# 预测测试集
y_pred = model.predict(X_test)

# 预测训练集
y_pred_train = model.predict(X_train)

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for测试集
mse_test = mean_squared_error(y_test, y_pred)
rmse_test = np.sqrt(mse_test)
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for训练集
mse_train = mean_squared_error(y_train, y_pred_train)
rmse_train = np.sqrt(mse_train)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")

# 计算R平方（R2）for测试集
r2_test = r2_score(y_test, y_pred)
print(f"测试集R平方（R2）: {r2_test:.4f}")

# 计算R平方（R2）for训练集
r2_train = r2_score(y_train, y_pred_train)
print(f"训练集R平方（R2）: {r2_train:.4f}")