# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 21:11:48 2024

@author: dell
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostRegressor # 导入AdaBoost回归器
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import numpy as np

filename = 'H:/Pythoncodes/1/OH-FringerprintAda.csv'
che = pd.read_csv(filename, header=0)

X = che.iloc[:, 3:]
y = che['k'].values.reshape(-1, 1)

scaler = StandardScaler()
y = np.log1p(y)
y = scaler.fit_transform(y)

X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=21)

# 替换为AdaBoost回归器
ada_regressor = AdaBoostRegressor(
    n_estimators=2000,  # 弱学习器的数量
    random_state=42     # 随机种子，保证结果可重复
)

ada_regressor.fit(X_train, y_train_scaled)

y_pred = ada_regressor.predict(X_test)
y_pred_train = ada_regressor.predict(X_train)

mse_test = mean_squared_error(y_test_scaled, y_pred)
rmse_test = np.sqrt(mse_test)
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

mse_train = mean_squared_error(y_train_scaled, y_pred_train)
rmse_train = np.sqrt(mse_train)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")

r2_test = r2_score(y_test_scaled, y_pred)
print(f"测试集R平方（R2）: {r2_test:.4f}")

r2_train = r2_score(y_train_scaled, y_pred_train)
print(f"训练集R平方（R2）: {r2_train:.4f}")

