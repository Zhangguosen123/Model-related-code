import tensorflow as tf

class BasicBlock(tf.keras.layers.Layer):
    expansion = 1  # 残差块的扩展系数

    def __init__(self, planes, stride=1):  # 初始化函数，定义了残差块的结构和参数
        super(BasicBlock, self).__init__()
        self.conv1 = tf.keras.layers.Conv2D(planes, kernel_size=3, strides=stride, padding='same', use_bias=False)  # 第一个卷积层
        self.bn1 = tf.keras.layers.BatchNormalization()  # 第一个批归一化层
        self.conv2 = tf.keras.layers.Conv2D(planes, kernel_size=3, strides=1, padding='same', use_bias=False)  # 第二个卷积层
        self.bn2 = tf.keras.layers.BatchNormalization()  # 第二个批归一化层

        if stride != 1:  # 如果步长不等于1，则需要对输入进行变换，保持尺寸一致
            self.shortcut = tf.keras.layers.Conv2D(planes, kernel_size=1, strides=stride, use_bias=False)  # 残差连接的卷积层
        else:
            self.shortcut = tf.identity  # 如果步长为1，则不需要额外变换，直接传递

    def call(self, x, training=False):  # 定义前向传播函数
        identity = self.shortcut(x)  # 获取残差连接的输入

        out = self.conv1(x)  # 第一个卷积层
        out = self.bn1(out, training=training)  # 第一个批归一化层
        out = tf.nn.relu(out)  # ReLU激活函数

        out = self.conv2(out)  # 第二个卷积层
        out = self.bn2(out, training=training)  # 第二个批归一化层

        out += identity  # 残差连接
        out = tf.nn.relu(out)  # ReLU激活函数
        return out

class ResNet(tf.keras.Model):
    def __init__(self, block, num_blocks, num_classes=10):  # 初始化函数，定义了ResNet的整体结构和参数
        super(ResNet, self).__init__()
        self.in_planes = 64  # 输入通道数

        self.conv1 = tf.keras.layers.Conv2D(64, kernel_size=3, strides=1, padding='same', use_bias=False)  # 输入卷积层
        self.bn1 = tf.keras.layers.BatchNormalization()  # 输入批归一化层
        self.layer1 = self._make_layer(block, 64, num_blocks[0], stride=1)  # 第一个残差块组
        self.layer2 = self._make_layer(block, 128, num_blocks[1], stride=2)  # 第二个残差块组
        self.layer3 = self._make_layer(block, 256, num_blocks[2], stride=2)  # 第三个残差块组
        self.layer4 = self._make_layer(block, 512, num_blocks[3], stride=2)  # 第四个残差块组
        self.avg_pool = tf.keras.layers.GlobalAveragePooling2D()  # 全局平均池化层
        self.fc = tf.keras.layers.Dense(num_classes)  # 全连接层

    def _make_layer(self, block, planes, num_blocks, stride):  # 定义构建残差块组的函数
        strides = [stride] + [1]*(num_blocks-1)  # 残差块组中每个残差块的步长设置
        layers = []  # 残差块组的层列表
        for stride in strides:
            layers.append(block(planes, stride))  # 构建每个残差块并添加到列表中
        return tf.keras.Sequential(layers)  # 返回一个Sequential模型，包含了所有的残差块

    def call(self, x, training=False):  # 定义前向传播函数
        out = self.conv1(x)  # 输入卷积层
        out = self.bn1(out, training=training)  # 输入批归一化层
        out = tf.nn.relu(out)  # ReLU激活函数

        out = self.layer1(out, training=training)  # 第一个残差块组
        out = self.layer2(out, training=training)  # 第二个残差块组
        out = self.layer3(out, training=training)  # 第三个残差块组
        out = self.layer4(out, training=training)  # 第四个残差块组

        out = self.avg_pool(out)  # 全局平均池化
        out = self.fc(out)  # 全连接层
        return out

def ResNet18():  # 创建ResNet-18模型的函数
    return ResNet(BasicBlock, [2,2,2,2])  # 返回ResNet-18模型，包含4个残差块组，每个组包含2个基础残差块

# 测试网络结构
def test():
    net = ResNet18()  # 创建ResNet-18模型
    y = net(tf.random.normal((1, 32, 32, 3)))  # 输入随机数据，测试模型
    print(y.shape)  # 打印模型输出的形状

test()  # 调用测试函数
