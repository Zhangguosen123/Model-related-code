# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 00:01:55 2024

@author: dell
"""
import pandas as pd  # 导入 pandas 库
import pubchempy as pcp # 导入 pubchempy 库
from rdkit import Chem # 从 RDKit 库中导入 Chem 模块
from rdkit.Chem import AllChem # 从 RDKit 库中导入 AllChem 模块
import numpy as np # 导入 numpy 库
from sklearn.model_selection import train_test_split # 导入train_test_split函数，用于将数据集分割为训练集和测试集
from sklearn.ensemble import RandomForestRegressor # 导入随机森林回归器
from sklearn.metrics import mean_squared_error, r2_score  # 导入均方误差函数和R平方函数
from sklearn.preprocessing import StandardScaler # 导入标准化器，用于对数据进行标准化处理
from sklearn.model_selection import cross_val_score
from bayes_opt import BayesianOptimization
import warnings
import numpy as np # 导入NumPy库，用于数值计算
import tensorflow as tf # 导入TensorFlow库
from tensorflow.keras.models import Sequential # 导入Sequential模型，用于搭建神经网络模型
from tensorflow.keras.layers import Dense # 导入Dense层，用于定义全连接层
from sklearn.model_selection import train_test_split # 导入train_test_split函数，用于将数据集分割为训练集和测试集
from sklearn.preprocessing import StandardScaler  # 导入标准化器，用于对数据进行标准化处理
import pandas as pd # 导入Pandas库，用于数据处理和分析
from sklearn.metrics import mean_squared_error # 导入均方误差函数
from sklearn.metrics import r2_score # 导入R平方函数
warnings.filterwarnings("ignore")

def MLP(fp_size,radius,batch_size):
    # 定义一个函数，用于将 SMILES 字符串转换为分子指纹
    def smiles_to_fingerprint(smiles, fp_size=int(fp_size)): 
        # 定义一个函数，将SMILES表示的分子转换为指纹，默认指纹大小为1024位
        molecule = Chem.MolFromSmiles(smiles) # 将 SMILES 字符串转换为分子对象
        if molecule is not None:  # 确保SMILES字符串有效
            fingerprint = AllChem.GetMorganFingerprintAsBitVect(molecule, radius=int(radius), nBits=fp_size)
            # 使用 Morgan 指纹方法生成分子指纹
            return np.array(fingerprint, dtype=int)   
            # 将指纹转换为 numpy 数组并返回，确保数据类型为整型
        else:
            return [np.nan]*fp_size  # 对于无效的SMILES字符串返回包含NaN的列表

    # 读取CSV文件并创建DataFrame对象
    filename = 'H:/Pythoncodes/1/OH-SMILES0.csv' # 文件路径
    che = pd.read_csv(filename, header=0)
    # 从指定路径的 CSV 文件中读取数据，并创建一个 DataFrame 对象。
    # 参数 header=0 表示使用第一行作为列名。

    # 应用函数并创建一个新的DataFrame来存储分子指纹
    # 注意：这里我们使用列表推导和*操作符来解包每个分子指纹
    fingerprints = [smiles_to_fingerprint(smiles) for smiles in che['Smiles']]
    # 将fingerprints列表转换为DataFrame，每个分子指纹占据一行
    fingerprint_df = pd.DataFrame(fingerprints)

    # 如果你想要在同一个DataFrame中保留原始的SMILES字符串和分子指纹，可以这样做：
    che_fingerprint = pd.concat([che, fingerprint_df], axis=1)


    che = che_fingerprint # 从CSV文件中读取数据到DataFrame中
    # 分离特征和目标变量，假设特征列从第4列开始，目标变量列名为'k'
    X = che.iloc[:,3:] # 特征变量
    y = che['k'].values.reshape(-1, 1)  # 目标变量：k列，重塑为2D数组以适应scaler

    scaler = StandardScaler()  # 初始化MinMaxScaler，用于对目标变量进行归一化处理

    y = np.log1p(y) # 对目标变量进行对数变换

    y = scaler.fit_transform(y) # 对目标变量进行归一化

    X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=21)
    # 分割数据为训练集和测试集

    # 定义神经网络模型
    model = Sequential([
        Dense(128, activation='relu', input_shape=(X_train.shape[1],)), # 输入层，128个神经元，ReLU激活函数
        Dense(640, activation='relu'), # 隐藏层，640个神经元，ReLU激活函数
        Dense(640, activation='relu'), # 隐藏层，640个神经元，ReLU激活函数
        Dense(1) # 输出层，一个神经元
    ])

    # 编译模型，选择优化器和损失函数
    model.compile(optimizer='adam', loss='mean_squared_error')

    # 训练模型
    history = model.fit(X_train, y_train_scaled, validation_split=0.2, epochs=1000, batch_size=int(batch_size))

    # 评估模型在测试集上的性能
    test_loss = model.evaluate(X_test, y_test_scaled)
    print('Test Loss:', test_loss)

    # 预测
    predictions = model.predict(X_test)

    # 计算和打印均方误差（MSE）、均方根误差（RMSE）和R^2 for测试集
    mse_test = mean_squared_error(y_test_scaled, predictions)
    rmse_test = np.sqrt(mse_test)
    # 计算R平方（R2）for测试集
    r2_test = r2_score(y_test_scaled, predictions)
    print(f"测试集R平方（R2）: {r2_test:.4f}")
    return r2_test

    # 定义超参数搜索空间
search_space = {
    'fp_size': (16, 8192),         
    'radius': (1, 10),
    'batch_size': (8, 64),            # 批量大小                       
}
opt = BayesianOptimization(
    MLP,
    search_space,
    random_state=24
)
opt.maximize( n_iter=100 )#一共观测/迭代多少次

params_best = opt.max["params"]
score_best = opt.max["target"]

    #打印最佳参数与最佳分数
print("\n","\n","best params: ", params_best,
          "\n","\n","best cvscore: ", score_best)