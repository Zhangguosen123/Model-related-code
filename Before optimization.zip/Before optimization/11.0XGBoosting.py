# -*- coding: utf-8 -*-
"""
Created on Sat Jun 15 12:16:06 2024

@author: dell
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor  # Import XGBRegressor from xgboost
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import numpy as np

# 读取数据
filename = 'H:/Pythoncodes/1/OH-FringerprintXGB.csv'
che = pd.read_csv(filename, header=0)

# 准备特征和目标变量
X = che.iloc[:, 3:]
y = che['k'].values.reshape(-1, 1)

# 标准化目标变量并进行对数变换
scaler = StandardScaler()
y = np.log1p(y)
y = scaler.fit_transform(y)

# 划分训练集和测试集
X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=21)

# 使用XGBoost替换ExtraTreesRegressor
xgb_regressor = XGBRegressor(
    n_estimators=1508,# 树的数量
    max_depth=24,       # 每棵树的最大深度
    learning_rate=0.1,  # 学习率
    random_state=42     # 随机种子，用于复现结果
)

xgb_regressor.fit(X_train, y_train_scaled)

# 预测及评估
y_pred = xgb_regressor.predict(X_test)
y_pred_train = xgb_regressor.predict(X_train)


mse_test = mean_squared_error(np.expm1(y_test_scaled), np.expm1(y_pred))
rmse_test = np.sqrt(mse_test)
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

mse_train = mean_squared_error(np.expm1(y_train_scaled), np.expm1(y_pred_train))
rmse_train = np.sqrt(mse_train)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")

r2_test = r2_score(np.expm1(y_test_scaled), np.expm1(y_pred))
print(f"测试集R平方（R2）: {r2_test:.4f}")

r2_train = r2_score(np.expm1(y_train_scaled), np.expm1(y_pred_train))
print(f"训练集R平方（R2）: {r2_train:.4f}")
