# -*- coding: utf-8 -*-
"""
Created on Tue Jun 18 18:05:25 2024

@author: dell
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import BayesianRidge
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import numpy as np

# 导入SHAP相关库
import shap

# 从CSV文件中读取数据到DataFrame中
filename = 'H:/Pythoncodes/1/OH-FringerprintBayR.csv'
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:, 3:]  # 特征变量从第4列开始
y = che['k'].values.reshape(-1, 1)

# 初始化标准化器，用于对目标变量进行归一化处理
scaler = StandardScaler()
y = np.log1p(y)  # 对目标变量进行对数变换
y = scaler.fit_transform(y)  # 对目标变量进行归一化处理

# 分割数据为训练集和测试集
X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=21)

# 创建贝叶斯岭回归模型实例
bayesian_ridge = BayesianRidge(alpha_1=14.895, alpha_2=28.919, lambda_1=21.378, lambda_2=25.235)

# 训练模型
bayesian_ridge.fit(X_train, y_train_scaled.ravel())

# 预测测试集和训练集
y_pred = bayesian_ridge.predict(X_test)
y_pred_train = bayesian_ridge.predict(X_train)

# 计算均方误差（MSE）和均方根误差（RMSE）for测试集
mse_test = mean_squared_error(y_test_scaled, y_pred)
rmse_test = np.sqrt(mse_test)
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

# 计算均方误差（MSE）和均方根误差（RMSE）for训练集
mse_train = mean_squared_error(y_train_scaled, y_pred_train)
rmse_train = np.sqrt(mse_train)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")

# 计算R平方（R2）for测试集和训练集
r2_test = r2_score(y_test_scaled, y_pred)
r2_train = r2_score(y_train_scaled, y_pred_train)
print(f"测试集R平方（R2）: {r2_test:.4f}")
print(f"训练集R平方（R2）: {r2_train:.4f}")

# 计算SHAP值
explainer = shap.Explainer(bayesian_ridge, X_train)
shap_values = explainer(X_train)

# 获取特征重要性排序和平均SHAP值
mean_abs_shap = np.abs(shap_values.values).mean(axis=0)
top_20_idx = np.argsort(mean_abs_shap)[-20:][::-1]  # 获取最重要的20个特征索引

# 输出最重要的20个特征和它们的平均SHAP值
print("最重要的20个特征及其对应的平均SHAP值:")
for idx in top_20_idx:
    feature_name = X_train.columns[idx]
    feature_mean_shap_value = mean_abs_shap[idx]
    print(f"{feature_name}: {feature_mean_shap_value:.4f}")

# 计算实际正SHAP值和负SHAP值
pos_shap_values = np.zeros(20)
neg_shap_values = np.zeros(20)

for i, idx in enumerate(top_20_idx):
    shap_vals = shap_values.values[:, idx]
    pos_shap_values[i] = np.sum(shap_vals[shap_vals > 0])
    neg_shap_values[i] = np.sum(shap_vals[shap_vals < 0])

print("\n实际正SHAP值:")
for i, value in enumerate(pos_shap_values):
    print(f"{X_train.columns[top_20_idx[i]]}: {value:.4f}")

print("\n实际负SHAP值:")
for i, value in enumerate(neg_shap_values):
    print(f"{X_train.columns[top_20_idx[i]]}: {value:.4f}")


