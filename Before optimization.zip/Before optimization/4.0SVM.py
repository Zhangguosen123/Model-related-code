# -*- coding: utf-8 -*-
"""
Created on Sat May 11 18:34:12 2024

@author: dell
"""
import pandas as pd # 导入Pandas库，用于数据处理和分析
from sklearn.model_selection import train_test_split # 导入train_test_split函数，用于将数据集分割为训练集和测试集
from sklearn.svm import SVR  # 导入支持向量机回归器
from sklearn.metrics import mean_squared_error # 导入均方误差函数
from sklearn.preprocessing import StandardScaler # 导入标准化器，用于对数据进行标准化处理
import numpy as np # 导入NumPy库，用于数值计算
from sklearn.metrics import r2_score # 导入R平方函数

# 假设che是你的DataFrame，并且它已经包含了1024个分子指纹的列和一个名为'k'的列
filename = 'H:/Pythoncodes/1/OH-FringerprintSVM.csv' # 文件路径
che = pd.read_csv(filename, header=0)  # 从CSV文件中读取数据到DataFrame中
# 分离特征和目标变量，假设特征列从第4列开始，目标变量列名为'k'
X = che.iloc[:,3:] # 特征变量
y = che['k'].values.reshape(-1, 1)  # 目标变量：k列，重塑为2D数组以适应scaler

# 初始化StandardScaler
# scaler = StandardScaler()

# 对目标变量进行归一化
# y_scaled = scaler.fit_transform(y)

y_scaled = np.log1p(y) # 对目标变量进行对数变换

X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y_scaled, test_size=0.2, random_state=21)
# 分割数据为训练集和测试集

# 创建支持向量机回归模型实例
svr_regressor = SVR(
    kernel='rbf',  # 核函数类型
    C=94,  # 正则化参数
    epsilon=0.54,  # epsilon在epsilon-SVR模型中设置epsilon管道的宽度
    gamma=0.117  # 核函数的系数（'scale'表示使用1 / (n_features * X.var())作为gamma的值）
)

# 训练模型
svr_regressor.fit(X_train, y_train_scaled.ravel())
# 使用ravel()将y_train_scaled转换为一维数组

# 预测测试集
y_pred = svr_regressor.predict(X_test)

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for测试集
mse_test = mean_squared_error(y_test_scaled, y_pred)
rmse_test = np.sqrt(mse_test)
r2_test = r2_score(y_test_scaled, y_pred)

print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")
print("测试集R^2 Score:", r2_test)

# 预测训练集
y_pred_train = svr_regressor.predict(X_train)

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for训练集
mse_train = mean_squared_error(y_train_scaled, y_pred_train)
rmse_train = np.sqrt(mse_train)
r2_train = r2_score(y_train_scaled, y_pred_train)

print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print("训练集R^2 Score:", r2_train)

# 使用 np.expm1 函数将对数变换后的值还原成原始的标签值
y_pred_original = np.expm1(y_pred)
y_test_original = np.expm1(y_test_scaled)

# 打印还原后的预测值和测试集目标变量的部分值以进行比较
print("还原后的预测值的前5个：", y_pred_original.flatten()[:5])
print("还原后的测试集目标变量的前5个：", y_test_original.flatten()[:5])

