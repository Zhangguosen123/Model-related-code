# -*- coding: utf-8 -*-
"""
Created on Tue Jun 18 19:19:53 2024

@author: dell
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import BayesianRidge
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import numpy as np
import shap

# 从CSV文件中读取数据到DataFrame中
filename = 'H:/Pythoncodes/1/OH-FringerprintBayR.csv'
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:, 3:]  # 特征变量从第4列开始
y = che['k'].values.reshape(-1, 1)

# 初始化标准化器，用于对目标变量进行归一化处理
scaler = StandardScaler()
y = np.log1p(y)  # 对目标变量进行对数变换
y = scaler.fit_transform(y)  # 对目标变量进行归一化处理

# 分割数据为训练集和测试集
X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=21)

# 创建贝叶斯岭回归模型实例
bayesian_ridge = BayesianRidge(alpha_1=14.895, alpha_2=28.919, lambda_1=21.378, lambda_2=25.235)

# 训练模型
bayesian_ridge.fit(X_train, y_train_scaled.ravel())

# 计算SHAP值
explainer = shap.Explainer(bayesian_ridge, X_train)
shap_values = explainer(X_train)

# 获取特征重要性排序和平均SHAP值
mean_abs_shap = np.abs(shap_values.values).mean(axis=0)
top_20_idx = np.argsort(mean_abs_shap)[-20:][::-1]  # 获取最重要的20个特征索引

# 输出最重要的20个特征和它们的平均SHAP值
print("最重要的20个特征及其对应的平均SHAP值:")
for idx in top_20_idx:
    feature_name = X_train.columns[idx]
    feature_mean_shap_value = mean_abs_shap[idx]
    print(f"{feature_name}: {feature_mean_shap_value:.4f}")

# 输出所有特征的实际SHAP值，并保存为CSV文件
shap_df = pd.DataFrame(shap_values.values, columns=X_train.columns)

# 只保留最重要的20个特征的SHAP值
shap_df_top_20 = shap_df.iloc[:, top_20_idx]

# 将结果保存为CSV文件
output_filename = 'top_20_shap_values.csv'
shap_df_top_20.to_csv(output_filename, index=False)

print(f"\n保存成功！SHAP值已保存到文件: {output_filename}")

