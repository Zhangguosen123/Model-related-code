# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 19:58:01 2024

@author: dell
"""
import pandas as pd  # 导入 pandas 库，并用 pd 别名表示
import pubchempy as pcp # 导入 pubchempy 库，并用 pcp 别名表示

# 读取CSV文件并创建DataFrame对象
filename = 'H:/Pythoncodes/1/s2.0-S0043135416302378-mmc1.csv' # 文件路径
df = pd.read_csv(filename, header=0) # 读取CSV文件并将其转换为DataFrame对象，指定第一行为列名
# 从 DataFrame df 中选取行索引从2开始（不包括索引2）的所有行，以及列索引从5开始（不包括索引5）到7（不包括索引7）的所有列。
che = df.iloc[2:, 5:7].reset_index(drop=True)

# 获取索引为2的列，并转换为 DataFrame
column_index_2 = df.iloc[2:, 2].reset_index(drop=True)
# column_index_2.name = 'Column_Index_2'  # 设定列名

# 合并两个 DataFrame
che = pd.concat([che, column_index_2], axis=1)

# 从 DataFrame df 中选取行索引从2开始（不包括索引2）的所有行，以及列索引从5开始（不包括索引5）到7（不包括索引7）的所有列。
che = che.reset_index(drop=True)
# 重置索引，丢弃之前的索引，生成一个新的从零开始的索引，然后更新到原始 Series 对象
che = che.replace('\?', '', regex=True) # 替换DataFrame中的特定字符串

# 然后，将所有元素转换为字符串形式
che.loc[0] = che.iloc[0].astype(str) # 将第一行的数据类型转换为字符串

def get_smiles_from_cas(cas_number): # 定义一个函数，用于根据CAS号获取对应的SMILES字符串。
    compounds = pcp.get_compounds(cas_number, 'name') # 从 PubChem 获取化合物信息
    if compounds:  # 如果找到化合物，则返回其SMILES字符串
        return compounds[0].isomeric_smiles  # 或使用canonical_smiles 
    else:
        return "Compound not found." # 如果未找到化合物，则返回提示信息

# 初始化一个空字典来存储CAS号和对应的SMILES字符串
if 'Result' not in che.columns: # 如果 DataFrame 中不存在名为 'Result' 的列，则创建该列并初始化为 pd.NA
    che['Result'] = pd.NA  # 或者使用None来初始化新列

# 循环遍历che DataFrame中的每一行
for index, row in che.iterrows():
    cas_number = row[0]  # 假设CAS号在选取的列中的第一列 # 获取当前行的 CAS 号
    smiles_result = get_smiles_from_cas(cas_number) # 根据 CAS 号获取 SMILES 字符串
    che.at[index, 'Result'] = smiles_result # 将获取的 SMILES 字符串写入 DataFrame

che.to_csv('H:/Pythoncodes/1/add class/OH-SMILESClass.csv', index=False) # 将DataFrame保存为CSV文件，不保存索引

