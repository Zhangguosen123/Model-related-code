# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 21:22:17 2024

@author: dell
"""
import pandas as pd  # 导入 pandas 库
import pubchempy as pcp # 导入 pubchempy 库
from rdkit import Chem # 从 RDKit 库中导入 Chem 模块
from rdkit.Chem import AllChem # 从 RDKit 库中导入 AllChem 模块
import numpy as np # 导入 numpy 库

# # 读取CSV文件并创建DataFrame对象
# filename = 'H:/Pythoncodes/1/add class/OH-SMILESClass0.csv'
# che = pd.read_csv(filename, header=0)

# # 删除第一列中重复数据所在的行，保留第一次出现的行
# che.drop_duplicates(subset=che.columns[0], keep='first', inplace=True)

# # 保存修改后的DataFrame到CSV文件
# che.to_csv(filename, index=False)

# 定义一个函数，用于将 SMILES 字符串转换为分子指纹
def smiles_to_fingerprint(smiles, fp_size=2048): 
    # 定义一个函数，将SMILES表示的分子转换为指纹，默认指纹大小为1024位
    molecule = Chem.MolFromSmiles(smiles) # 将 SMILES 字符串转换为分子对象
    if molecule is not None:  # 确保SMILES字符串有效
        fingerprint = AllChem.GetMorganFingerprintAsBitVect(molecule, radius=1, nBits=fp_size)
        # 使用 Morgan 指纹方法生成分子指纹
        return np.array(fingerprint, dtype=int)   
        # 将指纹转换为 numpy 数组并返回，确保数据类型为整型
    else:
        return [np.nan]*fp_size  # 对于无效的SMILES字符串返回包含NaN的列表

# 读取CSV文件并创建DataFrame对象
filename = 'H:/Pythoncodes/1/add class/OH-SMILESClass0.csv' # 文件路径
che = pd.read_csv(filename, header=0)
# 从指定路径的 CSV 文件中读取数据，并创建一个 DataFrame 对象。
# 参数 header=0 表示使用第一行作为列名。

# 应用函数并创建一个新的DataFrame来存储分子指纹
# 注意：这里我们使用列表推导和*操作符来解包每个分子指纹
fingerprints = [smiles_to_fingerprint(smiles) for smiles in che['Smiles']]
# 将fingerprints列表转换为DataFrame，每个分子指纹占据一行
fingerprint_df = pd.DataFrame(fingerprints)

# 如果你想要在同一个DataFrame中保留原始的SMILES字符串和分子指纹，可以这样做：
che_fingerprint = pd.concat([che, fingerprint_df], axis=1)

# 保存到CSV，不保留索引
che_fingerprint.to_csv('H:/Pythoncodes/1/add class/OH-FringerprintAda.csv', index=False)
