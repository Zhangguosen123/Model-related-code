# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd # 导入 pandas 库并简写为 pd
filename = 'train.csv' # 读取CSV文件并创建DataFrame对象
df = pd.read_csv('H:/Pythoncodes/1/s2.0-S0043135416302378-mmc1.csv', header=0)
# 从指定路径读取 CSV 文件并将其转换为 DataFrame 对象，指定第一行为列名
che = df.iloc[2:, 3]
# 选择 DataFrame 中第 3 列（索引为 2 的列），从第三行开始切片，创建一个 Series 对象
che = che.reset_index(drop=True)
# 重置索引，丢弃之前的索引，生成一个新的从零开始的索引，然后更新到原始 Series 对象

# 打印DataFrame内容
# from rdkit import Chem
# from rdkit import DataStructs
# from rdkit.Chem import AllChem
# from rdkit.Chem import Draw
# m1 = Chem.MolFromSmiles('ClC1=COCNC1')
# m2 = Chem.MolFromSmiles('BrC1=COCNC1')
# img = Draw.MolsToGridImage([m1, m2], subImgSize=(150, 150), legends=['ClC1CNCOC1', 'BrC1CNCOC1'])
# img

from rdkit import Chem # 导入化学信息处理工具包 RDKit
from rdkit.Chem import Draw # 导入 RDKit 中的绘图模块
from rdkit import Chem # 再次导入 RDKit 的化学信息处理模块
from rdkit import DataStructs # 导入 RDKit 的数据结构模块
from rdkit.Chem import AllChem # 导入 RDKit 中的化学信息处理模块的扩展化学功能
import matplotlib.pyplot as plt # 导入 matplotlib 库的绘图模块

m1 = Chem.MolFromSmiles('ClC1=COCNC1')  # 从 SMILES 格式的字符串创建分子对象 m1
m2 = Chem.MolFromSmiles('BrC1=COCNC1')  # 从 SMILES 格式的字符串创建分子对象 m2
img = Draw.MolsToGridImage([m1, m2], subImgSize=(150, 150), legends=['ClC1CNCOC1', 'BrC1CNCOC1'])
# 将分子对象 m1 和 m2 绘制成网格图像，并指定子图像大小和图例
plt.imshow(img) # 显示图像
plt.axis('off')  # 关闭坐标轴
plt.show()   # 展示图像
info = {}  # 创建一个空字典用于存储指纹信息
fp_explain = AllChem.GetMorganFingerprint(m1, 2, bitInfo=info)
# 生成分子 m1 的Morgan指纹，指定半径为2，并将指纹信息存储在字典 info 中
info # 输出存储的指纹信息
info2 = {}   # 创建一个空字典用于存储指纹信息
fp_explain = AllChem.GetMorganFingerprint(m2, 2, bitInfo=info2)
# 生成分子 m2 的Morgan指纹，指定半径为2，并将指纹信息存储在字典 info2 中
info2  # 输出存储的指纹信息

from rdkit import Chem
from rdkit.Chem import AllChem
import pandas as pd
import numpy as np
# 假设你有一个Series，名为che，其中包含SMILES字符串
# 例如：che = pd.Series(['C(C(=O)O)N', 'CCO', 'CCCN'])

# 定义一个函数，将SMILES字符串转换为分子指纹
def smiles_to_fingerprint(smiles, fp_size=2048): 
   # 定义一个函数，将SMILES表示的分子转换为指纹，默认指纹大小为2048位
    molecule = Chem.MolFromSmiles(smiles)
    # 使用Morgan指纹（一种常用的分子指纹）
    fingerprint = AllChem.GetMorganFingerprintAsBitVect(molecule, radius=2, nBits=fp_size)
    # 将分子指纹转换为NumPy数组并返回
    return np.array(fingerprint)

# 使用列表推导应用这个函数到每个SMILES字符串上
fingerprints = [smiles_to_fingerprint(smiles) for smiles in che]

# 现在，fingerprints是一个包含分子指纹的列表
