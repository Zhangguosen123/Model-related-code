# -*- coding: utf-8 -*-
"""
Created on Tue Jun 18 19:29:18 2024

@author: dell
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import BayesianRidge
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import numpy as np
import shap

# 从CSV文件中读取数据到DataFrame中
filename = 'H:/Pythoncodes/1/OH-FringerprintBayR.csv'
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:, 3:]  # 特征变量从第4列开始
y = che['k'].values.reshape(-1, 1)

# 初始化标准化器，用于对目标变量进行归一化处理
scaler = StandardScaler()
y = np.log1p(y)  # 对目标变量进行对数变换
y = scaler.fit_transform(y)  # 对目标变量进行归一化处理

# 分割数据为训练集和测试集
X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=21)

# 创建贝叶斯岭回归模型实例
bayesian_ridge = BayesianRidge(alpha_1=14.895, alpha_2=28.919, lambda_1=21.378, lambda_2=25.235)

# 训练模型
bayesian_ridge.fit(X_train, y_train_scaled.ravel())

# 计算SHAP值
explainer = shap.Explainer(bayesian_ridge, X_train)
shap_values = explainer(X_train)

# 输出所有特征的实际SHAP值，并保存为CSV文件
shap_df = pd.DataFrame(shap_values.values, columns=X_train.columns)
output_filename = 'all_shap_values.csv'
shap_df.to_csv(output_filename, index=False)

print(f"\n保存成功！所有特征的SHAP值已保存到文件: {output_filename}")

