# -*- coding: utf-8 -*-
"""
Created on Sat Jun  8 23:20:09 2024

@author: dell
"""
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, BatchNormalization, Activation, Add
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.preprocessing import MinMaxScaler
# 读取数据
filename = 'H:/Pythoncodes/1/OH-Fringerprint1024.csv'
che = pd.read_csv(filename, header=0)
X = che.iloc[:, 3:]
y = che['k'].values.reshape(-1, 1)

# 初始化StandardScaler
# scaler = StandardScaler()
scaler = MinMaxScaler(feature_range=(0, 1))
# 对目标变量进行对数变换和归一化
y_scaled = np.log1p(y)
y_scaled = scaler.fit_transform(y_scaled)

# 分割数据为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y_scaled, test_size=0.2, random_state=42)

# 定义残差块
def residual_block(input_data, num_neurons):
    x = Dense(num_neurons)(input_data)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dense(num_neurons)(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Add()([input_data, x])
    x = Activation('relu')(x)
    return x

# 定义残差神经网络模型
def ResidualNN(input_shape):
    # 定义输入层
    inputs = Input(shape=input_shape)
    # 第一个全连接层
    x = Dense(128, activation='relu')(inputs)
    # 批归一化层
    x = BatchNormalization()(x)
    # 第一个残差块
    x = residual_block(x, 128)
    # 第二个全连接层
    x = Dense(640, activation='relu')(x)
    # 批归一化层
    x = BatchNormalization()(x)
    # 第二个残差块
    x = residual_block(x, 640)
    # 第三个全连接层
    x = Dense(640, activation='relu')(x)
    # 批归一化层
    x = BatchNormalization()(x)
    # 第三个残差块
    x = residual_block(x, 640)
    # 输出层
    outputs = Dense(1)(x)
    # 创建模型
    model = Model(inputs, outputs)
    return model


# 创建残差神经网络模型
model = ResidualNN((X_train.shape[1],))

# 编译模型
model.compile(optimizer='adam', loss='mean_squared_error')

# 训练模型
history = model.fit(X_train, y_train, validation_split=0.2, epochs=100, batch_size=32)

# 评估模型
test_loss = model.evaluate(X_test, y_test)
print('Test Loss:', test_loss)

# 预测
predictions = model.predict(X_test)

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for测试集
mse_test = mean_squared_error(y_test, predictions)
rmse_test = np.sqrt(mse_test)
r2_test = r2_score(y_test, predictions)

print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")
print("测试集R^2 Score:", r2_test)
import matplotlib.pyplot as plt

# 获取训练过程中的损失记录
train_loss = history.history['loss']
val_loss = history.history['val_loss']

# 创建横坐标轴
epochs = range(1, len(train_loss) + 1)

# 绘制训练损失和验证损失曲线
plt.plot(epochs, train_loss, 'bo', label='Training loss')  # 'bo'表示蓝色圆点
plt.plot(epochs, val_loss, 'r', label='Validation loss')   # 'r'表示红色实线
plt.title('Training and validation loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()  # 添加图例
plt.show()
