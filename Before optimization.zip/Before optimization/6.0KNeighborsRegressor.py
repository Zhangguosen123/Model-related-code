# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 14:52:13 2024

@author: dell
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor # 替换为KNeighborsRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import numpy as np

# 读取数据
filename = 'H:/Pythoncodes/1/OH-FringerprintKNN.csv'
che = pd.read_csv(filename, header=0)

# 分离特征和目标变量
X = che.iloc[:,3:] 
y = che['k'].values.reshape(-1, 1)  

# 初始化标准化器
scaler = StandardScaler()

# 对目标变量进行对数变换和归一化处理
y = np.log1p(y)
y = scaler.fit_transform(y)

# 分割数据集
X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=21)

# 创建K最近邻回归模型实例
knn_regressor = KNeighborsRegressor(n_neighbors=5) # 设置KNeighborsRegressor的参数

# 训练模型
knn_regressor.fit(X_train, y_train_scaled)

# 预测测试集
y_pred = knn_regressor.predict(X_test)

# 预测训练集
y_pred_train = knn_regressor.predict(X_train)

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for测试集
mse_test = mean_squared_error(y_test_scaled, y_pred)
rmse_test = np.sqrt(mse_test)
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for训练集
mse_train = mean_squared_error(y_train_scaled, y_pred_train)
rmse_train = np.sqrt(mse_train)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")

# 计算R平方（R2）for测试集
r2_test = r2_score(y_test_scaled, y_pred)
print(f"测试集R平方（R2）: {r2_test:.4f}")

# 计算R平方（R2）for训练集
r2_train = r2_score(y_train_scaled, y_pred_train)
print(f"训练集R平方（R2）: {r2_train:.4f}")