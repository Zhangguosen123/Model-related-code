# -*- coding: utf-8 -*-
"""
Created on Sun Jun 16 11:25:30 2024

@author: dell
"""
import pandas as pd  # 导入Pandas库，用于数据处理和分析
from sklearn.model_selection import train_test_split  # 导入train_test_split函数，用于将数据集分割为训练集和测试集
from sklearn.linear_model import BayesianRidge  # 导入贝叶斯岭回归器
from sklearn.metrics import mean_squared_error, r2_score  # 导入均方误差函数和R平方函数
from sklearn.preprocessing import StandardScaler  # 导入标准化器，用于对数据进行标准化处理
import numpy as np  # 导入NumPy库，用于数值计算

# 假设che是你的DataFrame，并且它已经包含了1024个分子指纹的列和一个名为'k'的列
filename = 'H:/Pythoncodes/1/OH-FringerprintBayR.csv'  # 文件路径
che = pd.read_csv(filename, header=0)  # 从CSV文件中读取数据到DataFrame中

# 分离特征和目标变量，假设特征列从第4列开始，目标变量列名为'k'
X = che.iloc[:, 3:]  # 特征变量
y = che['k'].values.reshape(-1, 1)  # 目标变量：k列，重塑为2D数组以适应scaler

scaler = StandardScaler()  # 初始化标准化器，用于对目标变量进行归一化处理
y = np.log1p(y)  # 对目标变量进行对数变换
y = scaler.fit_transform(y)  # 对目标变量进行归一化处理

X_train, X_test, y_train_scaled, y_test_scaled = train_test_split(X, y, test_size=0.2, random_state=21)
# 分割数据为训练集和测试集

# 创建贝叶斯岭回归模型实例
bayesian_ridge = BayesianRidge(alpha_1=14.895, alpha_2=28.919, lambda_1=21.378, lambda_2=25.235)  
# alpha_1、alpha_2、lambda_1、lambda_2 是贝叶斯岭回归的超参数，这里设置为一个较小的值，可以根据需要调整

# 训练模型
bayesian_ridge.fit(X_train, y_train_scaled.ravel())  # ravel()用于将y_train_scaled从二维数组转换为一维数组

# 预测测试集
y_pred = bayesian_ridge.predict(X_test)

# 预测训练集
y_pred_train = bayesian_ridge.predict(X_train)

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for测试集
mse_test = mean_squared_error(y_test_scaled, y_pred)
rmse_test = np.sqrt(mse_test)
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")

# 计算和打印均方误差（MSE）和均方根误差（RMSE）for训练集
mse_train = mean_squared_error(y_train_scaled, y_pred_train)
rmse_train = np.sqrt(mse_train)
print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")

# 计算R平方（R2）for测试集
r2_test = r2_score(y_test_scaled, y_pred)
print(f"测试集R平方（R2）: {r2_test:.4f}")

# 计算R平方（R2）for训练集
r2_train = r2_score(y_train_scaled, y_pred_train)
print(f"训练集R平方（R2）: {r2_train:.4f}")

